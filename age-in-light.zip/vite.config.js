import { defineConfig } from 'vite';
import fs from 'node:fs';
import path from 'node:path';

/**
 * 生成媒体资源清单（media-manifest.json）。
 *
 * 为什么要它：页面需要在运行时判断「真实素材是否已就位」，
 * 缺失时降级为程序化占位。如果用 fetch 逐个探测不存在的文件，
 * 浏览器必然打出 404 错误日志，污染控制台。
 *
 * 改为在构建期扫描 public/media 目录，输出一份清单：
 * 运行时只请求这一个必定存在的文件（200），零 404。
 */
function mediaManifest() {
  const MEDIA_DIR = path.resolve(process.cwd(), 'public/media');
  const MANIFEST = 'media-manifest.json';

  /** 递归收集 media 目录下的所有文件（相对 public/ 的路径） */
  function scan() {
    const list = [];
    if (!fs.existsSync(MEDIA_DIR)) return list;
    const walk = (dir) => {
      for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
        const full = path.join(dir, entry.name);
        if (entry.isDirectory()) walk(full);
        else {
          const rel = path.relative(path.resolve(process.cwd(), 'public'), full).split(path.sep).join('/');
          list.push(rel);
        }
      }
    };
    walk(MEDIA_DIR);
    return list.sort();
  }

  return {
    name: 'media-manifest',
    configureServer(server) {
      server.middlewares.use((req, res, next) => {
        const url = (req.url || '').split('?')[0];
        if (!url.endsWith(MANIFEST)) return next();
        res.setHeader('Content-Type', 'application/json; charset=utf-8');
        res.setHeader('Cache-Control', 'no-cache');
        res.end(JSON.stringify({ files: scan() }));
      });
    },
    generateBundle() {
      this.emitFile({
        type: 'asset',
        fileName: MANIFEST,
        source: JSON.stringify({ files: scan() }, null, 2),
      });
    },
  };
}

export default defineConfig({
  base: './',
  plugins: [mediaManifest()],
  server: {
    host: '127.0.0.1',
    port: 5173,
  },
  build: {
    target: 'es2022',
    outDir: 'dist',
    chunkSizeWarningLimit: 1200,
  },
});
