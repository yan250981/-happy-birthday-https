import { chromium } from 'playwright-core';
import fs from 'node:fs';

const CHROME = 'C:/Program Files/Google/Chrome/Application/chrome.exe';
const browser = await chromium.launch({
  executablePath: CHROME,
  args: ['--use-gl=swiftshader', '--enable-unsafe-swiftshader', '--no-sandbox'],
});
fs.mkdirSync('.shots', { recursive: true });

/* ---------------- 桌面端 ---------------- */
const page = await browser.newPage({ viewport: { width: 1600, height: 900 } });
const errors = [];
page.on('pageerror', (e) => errors.push(`PAGEERROR: ${e.message}`));
page.on('console', (m) => {
  if (m.type() === 'error' && !m.text().includes('404')) errors.push(`CONSOLE: ${m.text()}`);
});

await page.goto('http://127.0.0.1:5173/', { waitUntil: 'networkidle' });
await page.waitForTimeout(2000);
await page.screenshot({ path: '.shots/F1-cover.png' });

await page.click('#btn-pointer');
await page.waitForTimeout(9000);
await page.screenshot({ path: '.shots/F2-text.png' });

// 设置面板（在吹蜡烛之前测试，避免被自动弹出的结局卡片遮挡）
await page.click('#btn-settings');
await page.waitForTimeout(600);
await page.screenshot({ path: '.shots/F7-settings.png' });
await page.keyboard.press('Escape');
await page.waitForTimeout(400);
const settingsClosed = await page.evaluate(() => (
  document.getElementById('settings')?.classList.contains('hidden')
));
console.log('SETTINGS CLOSED:', settingsClosed);

// 第二章：吹灭蜡烛测试 —— 逐根定位烛火，快速划过
await page.evaluate(() => document.querySelectorAll('#dots .dot')[2]?.click());
await page.waitForTimeout(4000);
await page.screenshot({ path: '.shots/F3-cake.png' });

const flames = () => page.evaluate(() => {
  const w = window.__world;
  const V = w.camera.position.constructor;
  return w.candles.map((c, i) => {
    c.flame.updateWorldMatrix(true, false);
    const p = new V(); c.flame.getWorldPosition(p);
    const pr = p.clone().project(w.camera);
    return {
      i, lit: c.lit,
      px: Math.round((pr.x + 1) / 2 * innerWidth),
      py: Math.round((1 - pr.y) / 2 * innerHeight),
    };
  });
});

// 逐根吹灭：快速划过
for (let round = 0; round < 8; round += 1) {
  const fs = await flames();
  const t = fs.find((f) => f.lit);
  if (!t) break;
  await page.waitForTimeout(600);
  const fresh = (await flames()).find((f) => f.i === t.i);
  await page.mouse.move(fresh.px - 50, fresh.py);
  await page.waitForTimeout(24);
  await page.mouse.move(fresh.px + 6, fresh.py);
  await page.waitForTimeout(100);
}

const blowState = await page.evaluate(() => ({
  candlesOut: window.__state?.candlesOut,
  chapter: window.__state?.chapter,
  lit: window.__world?.litCount,
}));
await page.screenshot({ path: '.shots/F4-after-blow.png' });

// 等自动推进到第四章（庆祝 + 烟花 + 结尾卡片）
await page.waitForTimeout(6000);
const celebrateState = await page.evaluate(() => ({
  chapter: window.__state?.chapter,
  celebrateAmount: window.__world?.celebrateAmount,
  finaleVisible: !document.getElementById('finale')?.hasAttribute('hidden')
    && getComputedStyle(document.getElementById('finale')).opacity !== '0',
}));
await page.screenshot({ path: '.shots/F6-finale.png' });

// 第三章烟花特写（重开后再跳到第四章）
await page.evaluate(() => document.getElementById('btn-replay')?.click());
await page.waitForTimeout(1200);
await page.evaluate(() => document.querySelectorAll('#dots .dot')[3]?.click());
await page.waitForTimeout(1400);
await page.screenshot({ path: '.shots/F5-fireworks.png' });
await page.waitForTimeout(2200);

/* ---------------- 手机端观礼版 ---------------- */
const mob = await browser.newPage({
  viewport: { width: 390, height: 844 },
  isMobile: true,
  hasTouch: true,
  deviceScaleFactor: 2,
  userAgent: 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 Mobile/15E148',
});
mob.on('pageerror', (e) => errors.push(`MOBILE PAGEERROR: ${e.message}`));
await mob.goto('http://127.0.0.1:5173/', { waitUntil: 'networkidle' });
await mob.waitForTimeout(2200);
await mob.screenshot({ path: '.shots/M1-cover.png' });
const mobState = await mob.evaluate(() => ({
  spectator: document.getElementById('app')?.classList.contains('is-spectator'),
}));
await mob.click('#btn-pointer');
await mob.waitForTimeout(8000);
await mob.screenshot({ path: '.shots/M2-story.png' });

console.log('BLOW STATE:', JSON.stringify(blowState));
console.log('CELEBRATE STATE:', JSON.stringify(celebrateState));
console.log('MOBILE:', JSON.stringify(mobState));
console.log('=== ERRORS ===');
console.log(errors.length ? errors.join('\n') : '(none)');
await browser.close();
