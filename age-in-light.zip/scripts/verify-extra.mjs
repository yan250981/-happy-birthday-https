/**
 * 补充功能验证：塑形彩蛋 / 保存成品图 / 重开 / URL 参数 / 复制链接
 */
import { chromium } from 'playwright-core';
import fs from 'node:fs';

const browser = await chromium.launch({
  executablePath: 'C:/Program Files/Google/Chrome/Application/chrome.exe',
  args: ['--use-gl=swiftshader', '--enable-unsafe-swiftshader', '--no-sandbox'],
});
const page = await browser.newPage({ viewport: { width: 1600, height: 900 } });
const errors = [];
page.on('pageerror', (e) => errors.push(`PAGEERROR: ${e.message}`));
page.on('console', (m) => { if (m.type() === 'error') errors.push(`CONSOLE: ${m.text()}`); });

/* ---------- URL 参数 ---------- */
await page.goto('http://127.0.0.1:5173/?to=%E5%B0%8F%E6%BB%A1&from=%E9%98%BF%E5%BC%A5&msg=%E7%94%9F%E6%97%A5%E5%BF%AB%E4%B9%90', { waitUntil: 'networkidle' });
await page.waitForTimeout(1800);

const cover = await page.evaluate(() => ({
  to: document.getElementById('in-to')?.value,
  from: document.getElementById('in-from')?.value,
  msg: document.getElementById('in-msg')?.value,
  url: location.search,
}));
console.log('URL PARAMS:', JSON.stringify(cover));

// 复制链接按钮
await page.click('#btn-copy');
await page.waitForTimeout(500);
const copyState = await page.evaluate(() => document.getElementById('btn-copy')?.textContent.trim());
console.log('COPY STATE:', copyState);

/* ---------- 进入故事 ---------- */
await page.click('#btn-pointer');
await page.waitForTimeout(1500);

/* ---------- 塑形彩蛋（捏合 → 心形/星星） ---------- */
await page.evaluate(() => document.querySelectorAll('#dots .dot')[1]?.click());
await page.waitForTimeout(3500);
const before = await page.evaluate(() => window.__world.field.uniforms.uMorphProgress.value);
await page.mouse.down();
await page.waitForTimeout(500);
await page.mouse.up();
await page.waitForTimeout(900);
const after = await page.evaluate(() => ({
  morph: window.__world.field.uniforms.uMorphProgress.value,
  tip: document.getElementById('tip')?.textContent.trim(),
}));
console.log('SHAPE (捏合):', JSON.stringify({ before: +before.toFixed(2), after }));

/* ---------- 保存成品图 ---------- */
const png = await page.evaluate(() => {
  const url = window.__world.capture();
  return { prefix: url.slice(0, 22), length: url.length };
});
console.log('CAPTURE:', JSON.stringify(png));

/* ---------- 重开 ---------- */
await page.evaluate(() => document.getElementById('btn-restart')?.click());
await page.waitForTimeout(1200);
const restart = await page.evaluate(() => ({
  chapter: window.__state.chapter,
  candlesOut: window.__state.candlesOut,
  finaleHidden: document.getElementById('finale')?.classList.contains('hidden'),
}));
console.log('RESTART:', JSON.stringify(restart));

/* ---------- 结尾卡片按钮 ---------- */
await page.evaluate(() => document.querySelectorAll('#dots .dot')[3]?.click());
await page.waitForTimeout(4200);
const finale = await page.evaluate(() => ({
  hidden: document.getElementById('finale')?.classList.contains('hidden'),
  text: document.getElementById('finale-text')?.textContent?.slice(0, 24),
  isFinaleClass: document.getElementById('app')?.classList.contains('is-finale'),
}));
console.log('FINALE:', JSON.stringify(finale));

console.log('ERRORS:', errors.length ? errors.join('\n') : '(none)');
await browser.close();
