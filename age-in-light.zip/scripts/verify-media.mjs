import { chromium } from 'playwright-core';
const browser = await chromium.launch({
  executablePath: 'C:/Program Files/Google/Chrome/Application/chrome.exe',
  args: ['--use-gl=swiftshader', '--enable-unsafe-swiftshader', '--no-sandbox'],
});
const page = await browser.newPage({ viewport: { width: 1600, height: 900 } });
const errors = [];
const failed = [];
page.on('pageerror', (e) => errors.push(`PAGEERROR: ${e.message}`));
page.on('console', (m) => { if (m.type() === 'error') errors.push(`CONSOLE: ${m.text()}`); });
page.on('response', (r) => { if (r.status() >= 400) failed.push(`${r.status()} ${r.url()}`); });

await page.goto('http://127.0.0.1:5173/', { waitUntil: 'networkidle' });
await page.waitForTimeout(3500);

const photos = await page.evaluate(() => {
  const cards = [...document.querySelectorAll('#photo-layer .photo-card')];
  return cards.map((c) => {
    const img = c.querySelector('img');
    return {
      name: c.querySelector('figcaption')?.textContent,
      // data: 表示程序化占位；否则是真实素材
      isReal: !img.src.startsWith('data:'),
      src: img.src.slice(0, 60),
    };
  });
});
console.log('PHOTO CARDS:');
photos.forEach((p) => console.log('  ', JSON.stringify(p)));
console.log('REAL COUNT:', photos.filter((p) => p.isReal).length, '/', photos.length);
console.log('FAILED REQUESTS:', failed.length ? failed.join('\n') : '(none)');
console.log('ERRORS:', errors.length ? errors.join('\n') : '(none)');
await browser.close();
