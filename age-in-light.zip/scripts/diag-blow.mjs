import { chromium } from 'playwright-core';

const browser = await chromium.launch({
  executablePath: 'C:/Program Files/Google/Chrome/Application/chrome.exe',
  args: ['--use-gl=swiftshader', '--enable-unsafe-swiftshader', '--no-sandbox'],
});
const page = await browser.newPage({ viewport: { width: 1600, height: 900 } });
page.on('pageerror', (e) => console.log('ERR>', e.message));

await page.goto('http://127.0.0.1:5173/', { waitUntil: 'networkidle' });
await page.waitForTimeout(1500);
await page.click('#btn-pointer');
await page.evaluate(() => document.querySelectorAll('#dots .dot')[2]?.click());
await page.waitForTimeout(4000);

// 包装 pointerInput.update，记录 hitTest 的调用细节
await page.evaluate(() => {
  const p = window.__pointer;
  window.__log = [];
  const orig = p.update.bind(p);
  p.update = (dt, hitTest) => {
    const wrapped = (ndc, sp) => {
      const r = hitTest(ndc, sp);
      // 同步算出每根烛火的距离，便于分析
      const w = window.__world;
      const V = w.camera.position.constructor;
      const dists = w.candles.map((c) => {
        if (!c.lit) return null;
        c.flame.updateWorldMatrix(true, false);
        const v = new V(); c.flame.getWorldPosition(v);
        const pr = v.project(w.camera);
        return +Math.hypot(pr.x - ndc.x, pr.y - ndc.y).toFixed(4);
      });
      window.__log.push({
        hit: r,
        sp: +sp.toFixed(2),
        ndc: [+ndc.x.toFixed(3), +ndc.y.toFixed(3)],
        dists,
        cool: +p._blowCool.toFixed(2),
        sCool: +window.__state.blowCooldown.toFixed(2),
        ch: window.__state.chapter,
      });
      if (window.__log.length > 60) window.__log.shift();
      return r;
    };
    orig(dt, wrapped);
  };
});

const snap = () => page.evaluate(() => ({
  out: window.__state.candlesOut,
  lit: window.__world.litCount,
  speed: +window.__pointer.speed.toFixed(2),
}));

const flames = () => page.evaluate(() => {
  const w = window.__world;
  const V = w.camera.position.constructor;
  return w.candles.map((c, i) => {
    c.flame.updateWorldMatrix(true, false);
    const p = new V(); c.flame.getWorldPosition(p);
    const pr = p.clone().project(w.camera);
    return { i, lit: c.lit, px: Math.round((pr.x + 1) / 2 * innerWidth), py: Math.round((1 - pr.y) / 2 * innerHeight) };
  });
});

for (let round = 0; round < 3; round += 1) {
  const fs = await flames();
  const t = fs.find((f) => f.lit);
  if (!t) break;
  await page.waitForTimeout(650);
  await page.evaluate(() => { window.__log.length = 0; });
  const fresh = (await flames()).find((f) => f.i === t.i);
  console.log(`\n--- 目标烛火 #${fresh.i} 屏幕坐标 (${fresh.px}, ${fresh.py}) ---`);
  await page.mouse.move(fresh.px - 60, fresh.py);
  await page.waitForTimeout(30);
  await page.mouse.move(fresh.px + 8, fresh.py, { steps: 2 });
  await page.waitForTimeout(80);
  const log = await page.evaluate(() => window.__log);
  console.log('snap:', JSON.stringify(await snap()));
  // 只打印 hitTest 调用记录（最后 8 条）
  console.log('hitTest 记录（末 8 条）:');
  log.slice(-8).forEach((r) => console.log('  ', JSON.stringify(r)));
}

await browser.close();
