/**
 * 生成站点 favicon：深紫底 + 金色四角星芒。
 * 用 node 写 PNG（无依赖）：手写最小 PNG 编码器。
 */
import fs from 'node:fs';
import zlib from 'node:zlib';

const S = 64;

/* ---------- 简易 RGBA 画布 ---------- */
const px = new Uint8Array(S * S * 4);
const set = (x, y, r, g, b, a) => {
  if (x < 0 || y < 0 || x >= S || y >= S) return;
  const i = (y * S + x) * 4;
  const na = a / 255;
  px[i] = Math.round(px[i] * (1 - na) + r * na);
  px[i + 1] = Math.round(px[i + 1] * (1 - na) + g * na);
  px[i + 2] = Math.round(px[i + 2] * (1 - na) + b * na);
  px[i + 3] = Math.max(px[i + 3], a);
};

/* 背景：深紫径向渐变 */
for (let y = 0; y < S; y += 1) {
  for (let x = 0; x < S; x += 1) {
    const dx = (x - S / 2) / (S / 2);
    const dy = (y - S / 2) / (S / 2);
    const d = Math.min(1, Math.hypot(dx, dy));
    const r = Math.round(5 + 18 * (1 - d));
    const g = Math.round(4 + 10 * (1 - d));
    const b = Math.round(13 + 36 * (1 - d));
    set(x, y, r, g, b, 255);
  }
}

/* 四角星芒：中心亮，四个尖角渐隐 */
const cx = S / 2 - 0.5;
const cy = S / 2 - 0.5;
const spikes = [
  [0, -1], [1, 0], [0, 1], [-1, 0],
];
for (let y = 0; y < S; y += 1) {
  for (let x = 0; x < S; x += 1) {
    const dx = x - cx;
    const dy = y - cy;
    const r = Math.hypot(dx, dy);
    if (r > 27) continue;

    // 四向尖角的距离场
    let spike = 0;
    for (const [sx, sy] of spikes) {
      // 沿尖角方向的投影
      const proj = Math.abs(dx * sx + dy * sy);
      // 垂直于尖角方向的偏移
      const perp = Math.abs(dx * sy - dy * sx);
      // 尖角形状：垂直偏移越小、越靠外越暗
      const shape = Math.max(0, 1 - perp / (3.4 + proj * 0.30));
      const fade = Math.max(0, 1 - proj / 27);
      spike = Math.max(spike, shape * fade);
    }
    // 中心圆晕
    const core = Math.max(0, 1 - r / 8.5) ** 2;
    const v = Math.min(1, spike * 0.95 + core * 0.9);

    if (v > 0.01) {
      // 金色 → 玫瑰色渐变
      const t = Math.min(1, r / 26);
      const cr = Math.round(255);
      const cg = Math.round(215 - 60 * t);
      const cb = Math.round(160 - 20 * t);
      set(x, y, cr, cg, cb, Math.round(255 * v));
    }
  }
}

/* ---------- PNG 编码 ---------- */
const raw = Buffer.alloc((S * 4 + 1) * S);
for (let y = 0; y < S; y += 1) {
  raw[y * (S * 4 + 1)] = 0; // filter type 0
  Buffer.from(px.buffer, y * S * 4, S * 4).copy(raw, y * (S * 4 + 1) + 1);
}

const crcTable = (() => {
  const t = new Int32Array(256);
  for (let n = 0; n < 256; n += 1) {
    let c = n;
    for (let k = 0; k < 8; k += 1) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    t[n] = c;
  }
  return t;
})();

const crc32 = (buf) => {
  let c = 0xffffffff;
  for (let i = 0; i < buf.length; i += 1) c = crcTable[(c ^ buf[i]) & 0xff] ^ (c >>> 8);
  return (c ^ 0xffffffff) >>> 0;
};

const chunk = (type, data) => {
  const len = Buffer.alloc(4);
  len.writeUInt32BE(data.length);
  const body = Buffer.concat([Buffer.from(type, 'ascii'), data]);
  const crc = Buffer.alloc(4);
  crc.writeUInt32BE(crc32(body));
  return Buffer.concat([len, body, crc]);
};

const ihdr = Buffer.alloc(13);
ihdr.writeUInt32BE(S, 0);
ihdr.writeUInt32BE(S, 4);
ihdr[8] = 8;   // bit depth
ihdr[9] = 6;   // RGBA
ihdr[10] = 0;
ihdr[11] = 0;
ihdr[12] = 0;

const png = Buffer.concat([
  Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]),
  chunk('IHDR', ihdr),
  chunk('IDAT', zlib.deflateSync(raw, { level: 9 })),
  chunk('IEND', Buffer.alloc(0)),
]);

fs.mkdirSync('public', { recursive: true });
fs.writeFileSync('public/favicon.png', png);
console.log(`public/favicon.png 已生成（${S}×${S}, ${png.length} 字节）`);
