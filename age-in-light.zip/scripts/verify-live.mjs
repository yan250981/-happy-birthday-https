import { chromium } from 'playwright-core';

const BASE = 'https://age-in-light.app.workbuddy.host';
const URL = `${BASE}/?sharecode=KRRLEWA7HM&to=%E5%B0%8F%E7%BE%8E&from=%E5%B0%8F%E5%88%98&msg=%E4%BB%8A%E5%B9%B4%E4%B9%9F%E8%A6%81%E5%A5%BD%E5%A5%BD%E5%90%83%E9%A5%AD%E5%95%A6`;

const browser = await chromium.launch({
  executablePath: 'C:/Program Files/Google/Chrome/Application/chrome.exe',
  args: ['--use-gl=swiftshader', '--enable-unsafe-swiftshader', '--no-sandbox'],
});
const page = await browser.newPage({ viewport: { width: 1600, height: 900 } });

const errors = [];
const httpErrors = [];
page.on('console', (m) => { if (m.type() === 'error') errors.push(m.text()); });
page.on('pageerror', (e) => errors.push('PAGEERROR ' + e.message));
page.on('response', (r) => { if (r.status() >= 400) httpErrors.push(`${r.status()} ${r.url()}`); });

await page.goto(URL, { waitUntil: 'networkidle', timeout: 120000 });
await page.waitForTimeout(2500);
await page.click('#btn-pointer');
await page.waitForTimeout(2500);

// 跳到第三章
await page.evaluate(() => document.querySelectorAll('#dots .dot')[2]?.click());
await page.waitForTimeout(6500);
await page.screenshot({ path: '.shots/LIVE-2-cake.png' });

const chap = await page.evaluate(() => document.getElementById('chapter-title')?.textContent?.trim());
console.log('CHAPTER:', chap);

// 烛焰带：截图上 5 根烛焰集中在 x≈600-1000, y≈260-380（1600x900 视口）
// 判定方式 = 产品验收标准：5 根全灭后自动进入第四章并弹出结尾卡片
const Y = 300;
for (let round = 0; round < 4; round += 1) {
  for (let x = 560; x <= 1020; x += 45) {
    await page.mouse.move(x - 40, Y);
    await page.mouse.move(x + 8, Y, { steps: 3 });
  }
  await page.waitForTimeout(500);
  const st = await page.evaluate(() => ({
    chapter: document.getElementById('chapter-title')?.textContent?.trim(),
    finale: !document.getElementById('finale')?.classList.contains('hidden'),
  }));
  console.log(`ROUND ${round + 1}:`, JSON.stringify(st));
  if (st.finale) break;
}

// 蓄力兜底：在烛焰带中央停住不动
await page.mouse.move(800, 300);
await page.waitForTimeout(1500);
await page.mouse.move(820, 300);
await page.waitForTimeout(1500);

await page.waitForTimeout(8000);
await page.screenshot({ path: '.shots/LIVE-3-finale.png' });

const fin = await page.evaluate(() => ({
  chapter: document.getElementById('chapter-title')?.textContent?.trim(),
  finaleShown: !document.getElementById('finale')?.classList.contains('hidden'),
  finaleText: document.getElementById('finale')?.innerText?.replace(/\s+/g, ' ').slice(0, 100),
  appClass: document.getElementById('app')?.className,
}));
console.log('FINAL:', JSON.stringify(fin));

console.log('HTTP_ERRORS:', httpErrors.length ? JSON.stringify(httpErrors, null, 1) : 'none');
console.log('CONSOLE_ERRORS:', errors.length ? JSON.stringify(errors.slice(0, 6), null, 1) : 'none');

await browser.close();
