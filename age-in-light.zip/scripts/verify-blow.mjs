/**
 * 吹灭蜡烛专项验证：
 * 路径 A —— 快速划过烛火（吹一口气）
 * 路径 B —— 指针停在烛火旁蓄力（兜底）
 */
import { chromium } from 'playwright-core';

const browser = await chromium.launch({
  executablePath: 'C:/Program Files/Google/Chrome/Application/chrome.exe',
  args: ['--use-gl=swiftshader', '--enable-unsafe-swiftshader', '--no-sandbox'],
});
const page = await browser.newPage({ viewport: { width: 1600, height: 900 } });
const errors = [];
page.on('pageerror', (e) => errors.push(e.message));
page.on('console', (m) => { if (m.type() === 'error') errors.push(m.text()); });

await page.goto('http://127.0.0.1:5173/', { waitUntil: 'networkidle' });
await page.waitForTimeout(1500);
await page.click('#btn-pointer');
await page.evaluate(() => document.querySelectorAll('#dots .dot')[2]?.click());
await page.waitForTimeout(4000);

const snap = () => page.evaluate(() => ({
  out: window.__state.candlesOut,
  chapter: window.__state.chapter,
  lit: window.__world.litCount,
  charge: +window.__state.blowCharge.toFixed(2),
  speed: +window.__pointer.speed.toFixed(2),
}));

const flames = () => page.evaluate(() => {
  const w = window.__world;
  const V = w.camera.position.constructor;
  return w.candles.map((c, i) => {
    c.flame.updateWorldMatrix(true, false);
    const p = new V(); c.flame.getWorldPosition(p);
    const pr = p.clone().project(w.camera);
    return {
      i, lit: c.lit,
      px: Math.round((pr.x + 1) / 2 * innerWidth),
      py: Math.round((1 - pr.y) / 2 * innerHeight),
    };
  });
});

console.log('=== 初始 ===', JSON.stringify(await snap()));

/* ---------- 路径 A：快速划过 ---------- */
console.log('\n--- 路径 A：快速划过 ---');
for (let round = 0; round < 3; round += 1) {
  const fs = await flames();
  const t = fs.find((f) => f.lit);
  if (!t) break;
  await page.waitForTimeout(600);
  const fresh = (await flames()).find((f) => f.i === t.i);
  // 从左侧靠近后快速划过
  await page.mouse.move(fresh.px - 50, fresh.py);
  await page.waitForTimeout(24);
  await page.mouse.move(fresh.px + 6, fresh.py);
  await page.waitForTimeout(100);
  console.log(`  划过 #${fresh.i} →`, JSON.stringify(await snap()));
}

/* ---------- 路径 B：停留蓄力 ---------- */
console.log('\n--- 路径 B：停留蓄力 ---');
for (let round = 0; round < 4; round += 1) {
  const fs = await flames();
  const t = fs.find((f) => f.lit);
  if (!t) break;
  await page.waitForTimeout(600);
  const fresh = (await flames()).find((f) => f.i === t.i);
  // 移动到烛火正上方后完全静止
  await page.mouse.move(fresh.px, fresh.py);
  await page.waitForTimeout(300);
  const mid = await snap();
  await page.waitForTimeout(900);
  const after = await snap();
  console.log(`  停留 #${fresh.i}: 0.3s →`, JSON.stringify(mid));
  console.log(`  停留 #${fresh.i}: 1.2s →`, JSON.stringify(after));
}

console.log('\n=== 最终 ===', JSON.stringify(await snap()));
console.log('烛火状态:', JSON.stringify((await flames()).map((f) => ({ i: f.i, lit: f.lit }))));
console.log('ERRORS:', errors.length ? JSON.stringify(errors) : '无');

const final = await snap();
console.log(final.out >= 5 ? '✅ 5 根蜡烛全部吹灭' : `❌ 只吹灭了 ${final.out} 根`);

await browser.close();
