/**
 * 素材层。
 * 所有素材均按「可替换」设计：真实文件放在 public/media/ 下对应目录，
 * 缺失时自动降级为程序化生成的占位物。
 *
 * public/media/photos/   照片（jpg/png），命名 01.jpg ~ 12.jpg
 * public/media/video/    祝福视频 mp4
 * public/media/bgm.mp3   背景音乐
 * public/media/signature.png  手写签名 / logo
 */

const PHOTO_NAMES = [
  ['林小满', '一起看过的流星雨'],
  ['陈屿', '那年夏天的海'],
  ['周晚意', '食堂三楼的红烧肉'],
  ['苏晓', '凌晨三点的代码'],
  ['何屿', '球场上的绝杀'],
  ['许可', '图书馆的第七排'],
  ['江予', '一路向北的公路'],
  ['温故', '被雨淋湿的那把伞'],
  ['白露', '秋天的第一杯奶茶'],
  ['叶知秋', '旧校服的口袋'],
  ['顾南', '天台上的流星'],
  ['钟意', '无数次晚安'],
];

const FALLBACK_GLYPHS = ['满', '屿', '晚', '晓', '何', '可', '予', '故', '露', '秋', '南', '意'];

/**
 * 照片清单。src 存在则用真实照片，否则生成占位色块 + 姓氏字。
 */
export const PHOTOS = PHOTO_NAMES.map(([name, note], i) => ({
  name,
  note,
  src: `/media/photos/${String(i + 1).padStart(2, '0')}.jpg`,
  fallback: FALLBACK_GLYPHS[i],
}));

export const VIDEO_ITEM = {
  name: '一段视频',
  note: '来自朋友们的祝福',
  src: '/media/video/wish.mp4',
};

export const SIGNATURE = {
  src: '/media/signature.png',
  fallbackText: '—— 来自爱你的朋友们',
};

export const BGM = {
  src: '/media/bgm.mp3',
  /** 没有音频文件时，页面用 WebAudio 合成环境音，不出现空白播放器 */
  silentFallback: true,
};

/**
 * 生成占位头像的 dataURL（纯 CSS 渐变 + 文字，不用外部资源）
 */
export function makeAvatar(glyph, seed = 0) {
  const hue = (seed * 47 + 265) % 360;
  const hue2 = (hue + 42) % 360;
  const c = document.createElement('canvas');
  c.width = 128;
  c.height = 128;
  const ctx = c.getContext('2d');
  const g = ctx.createLinearGradient(0, 0, 128, 128);
  g.addColorStop(0, `hsl(${hue}, 46%, 26%)`);
  g.addColorStop(1, `hsl(${hue2}, 40%, 12%)`);
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, 128, 128);
  // 光斑
  const rg = ctx.createRadialGradient(42, 38, 4, 42, 38, 76);
  rg.addColorStop(0, `hsla(${hue}, 78%, 72%, .34)`);
  rg.addColorStop(1, 'hsla(0,0%,0%,0)');
  ctx.fillStyle = rg;
  ctx.fillRect(0, 0, 128, 128);
  ctx.fillStyle = `hsla(${hue}, 62%, 84%, .92)`;
  ctx.font = '500 58px "Songti SC", "STSong", serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText(glyph, 64, 66);
  return c.toDataURL('image/png');
}

/**
 * 读取构建期生成的资源清单。
 *
 * 清单由 vite.config.js 的 media-manifest 插件扫描 public/media 生成，
 * 运行时只请求这一个必定存在的文件（200），
 * 避免了「逐个 fetch 探测不存在的文件」必然产生的 404 控制台噪音。
 */
let manifestPromise = null;

function loadManifest() {
  if (!manifestPromise) {
    manifestPromise = fetch(`${import.meta.env.BASE_URL}media-manifest.json`, {
      cache: 'no-cache',
    })
      .then((res) => (res.ok ? res.json() : { files: [] }))
      .then((data) => new Set(data.files || []))
      .catch(() => new Set());
  }
  return manifestPromise;
}

/**
 * 静默探测：返回存在于清单中的那些 url，其余为 null。
 * 不会产生任何 404 请求。
 */
export async function probeAssetsQuietly(urls) {
  const set = await loadManifest();
  return urls.map((u) => {
    // '/media/photos/01.jpg' → 'media/photos/01.jpg'
    const rel = u.replace(/^\.?\//, '').replace(/^\//, '');
    return set.has(rel) ? u : null;
  });
}
