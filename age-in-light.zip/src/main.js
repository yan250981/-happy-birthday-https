import './styles.css';
import * as THREE from 'three';
import { World, CHAPTERS } from './scene/World.js';
import { HandInput } from './interaction/HandInput.js';
import { PointerInput } from './interaction/PointerInput.js';
import { Sfx } from './audio/Sfx.js';
import { UI } from './ui/UI.js';
import { PhotoLayer } from './ui/PhotoLayer.js';
import { probeAssetsQuietly, SIGNATURE, BGM } from './assets/media.js';

/* ============================================================
   岁光 · AGE IN LIGHT
   流程：署名封面 → 授权 → 聚合入场 → 手势扰动/塑形
        → 逐根吹灭 → 烟花 + 祝福揭晓 → 保存成品
   ============================================================ */

const ui = new UI();
const sfx = new Sfx();
const photos = new PhotoLayer(document.getElementById('photo-layer'));

const params = new URLSearchParams(location.search);
const state = {
  to: params.get('to') || '',
  from: params.get('from') || '',
  msg: params.get('msg') || '',
  chapter: 0,
  running: false,
  handMode: false,
  handsReady: false,
  candlesOut: 0,
  totalCandles: 5,
  celebrateDone: false,
  quality: 'high',
  spectator: false,
  shapeCooldown: 0,
  blowCooldown: 0,
  blowCharge: 0,
  blowTarget: null,
};

/* ------------------------------------------------------ 画质判定 */
function detectQuality() {
  const mem = navigator.deviceMemory || 4;
  const cores = navigator.hardwareConcurrency || 4;
  const mobile = /Android|iPhone|iPad|iPod|Mobile/i.test(navigator.userAgent);
  if (mobile || mem <= 2 || cores <= 2) return 'low';
  if (mem <= 4 || cores <= 4) return 'medium';
  return 'high';
}
state.quality = detectQuality();
state.spectator = window.matchMedia('(pointer: coarse)').matches && window.innerWidth < 900;

let world;
let handInput = null;
let pointerInput = null;
let bgm = null;

/* ------------------------------------------------------ 初始化 */
async function init() {
  ui.setQuality(state.quality);
  ui.setSpectator(state.spectator);
  ui.setCoverData(state);

  // 回填输入框
  const inTo = document.getElementById('in-to');
  const inFrom = document.getElementById('in-from');
  const inMsg = document.getElementById('in-msg');
  inTo.value = state.to;
  inFrom.value = state.from;
  inMsg.value = state.msg;
  [inTo, inFrom, inMsg].forEach((el) => {
    el.addEventListener('input', () => {
      state.to = inTo.value.trim();
      state.from = inFrom.value.trim();
      state.msg = inMsg.value.trim();
      ui.setCoverData(state);
      syncUrl();
    });
  });

  ui.setLoader('正在点亮星尘…');
  world = new World(document.getElementById('scene'), { quality: state.quality });
  world.setChapter(0);
  // 首帧直接呈现序幕形态，避免开场从原点炸开
  world.field.morph = 1;
  world.field.uniforms.uMorphProgress.value = 1;

  // 指针输入始终可用，作为降级保障
  pointerInput = new PointerInput(world.canvas, {
    onBlow: (target) => tryBlow(target),
    onShape: (ndc) => {
      // 在烛火上按下是「吹灭」，不是「塑形」—— 避免两个手势打架
      if (state.chapter === 2 && findNearestCandle(ndc)) return;
      tryShape(true);
    },
    onMove: (ndc) => {
      world.parallaxTarget.set(ndc.x * 0.5, ndc.y * 0.4);
    },
  });

  bindUI();
  loop();

  // 素材延迟加载：不阻塞首屏
  setTimeout(async () => {
    await photos.load();
    photos.setVisible(false);
  }, 400);

  // 背景音乐：存在则播放，不存在则静默
  const [bgmUrl] = await probeAssetsQuietly([BGM.src]);
  if (bgmUrl) {
    bgm = new Audio(BGM.src);
    bgm.loop = true;
    bgm.volume = 0.35;
  }

  ui.hideLoader();
  // 开发调试钩子：便于在控制台检查粒子形态
  if (import.meta.env.DEV) {
    window.__world = world;
    window.__state = state;
    window.__pointer = pointerInput;
  }
  ui.showTip(
    state.spectator
      ? '当前为观礼版 · 在电脑上打开可解锁手势互动'
      : '准备好后，选择一种方式开始',
    5200
  );
}

/* ------------------------------------------------------ URL 同步 */
function syncUrl() {
  const p = new URLSearchParams();
  if (state.to) p.set('to', state.to);
  if (state.from) p.set('from', state.from);
  if (state.msg) p.set('msg', state.msg);
  const q = p.toString();
  history.replaceState(null, '', q ? `?${q}` : location.pathname);
}

/* ------------------------------------------------------ UI 绑定 */
function bindUI() {
  document.getElementById('btn-hands').addEventListener('click', () => startWithHands());
  document.getElementById('btn-pointer').addEventListener('click', () => startWithPointer());

  document.getElementById('btn-copy').addEventListener('click', async () => {
    syncUrl();
    const url = location.href;
    try {
      await navigator.clipboard.writeText(url);
      ui.setCopyState('已复制');
    } catch {
      ui.setCopyState('请手动复制地址栏');
    }
    setTimeout(() => ui.setCopyState(''), 2400);
  });

  document.getElementById('btn-settings').addEventListener('click', () => ui.toggleSettings());
  document.getElementById('btn-sound').addEventListener('click', (e) => {
    const on = !e.currentTarget.classList.contains('is-on');
    e.currentTarget.classList.toggle('is-on', on);
    sfx.setMuted(!on);
    if (on && bgm) bgm.play().catch(() => {});
    if (!on && bgm) bgm.pause();
  });

  document.getElementById('btn-toggle-hands').addEventListener('click', async () => {
    if (state.handsReady) {
      handInput.stop();
      state.handsReady = false;
      ui.setHandsState(false);
      ui.setCamVisible(false);
      ui.toast('已关闭手势，回到指针模式');
      return;
    }
    await enableHands();
  });

  document.getElementById('seg-quality').addEventListener('click', (e) => {
    const btn = e.target.closest('button');
    if (!btn) return;
    const q = btn.dataset.q;
    const resolved = q === 'auto' ? detectQuality() : q;
    state.quality = resolved;
    ui.setQuality(q);
    ui.toast(q === 'auto' ? `画质：自动（${resolved}）` : `画质：${resolved === 'high' ? '高' : '低'}`);
  });

  document.getElementById('btn-restart').addEventListener('click', () => {
    ui.toggleSettings(false);
    restart();
  });

  document.getElementById('cap-skip').addEventListener('click', () => goChapter(state.chapter + 1));
  document.getElementById('caption-icon').addEventListener('click', () => {
    world.setChapter(state.chapter);
    sfx.whoosh(true);
  });

  document.getElementById('btn-replay').addEventListener('click', () => restart());
  document.getElementById('btn-capture').addEventListener('click', () => {
    const url = world.capture();
    const a = document.createElement('a');
    a.href = url;
    a.download = `岁光-${state.to || '生日'}.png`;
    a.click();
    ui.toast('成品图已保存');
  });

  ui.onDot = (i) => goChapter(i);
}

/* ------------------------------------------------------ 启动 */
async function startWithHands() {
  sfx.unlock();
  if (bgm) bgm.play().catch(() => {});
  ui.hideCover();
  beginStory();

  const ok = await enableHands();
  if (!ok) {
    ui.toast('未获得摄像头权限，已切换为指针模式');
  }
}

function startWithPointer() {
  sfx.unlock();
  if (bgm) bgm.play().catch(() => {});
  ui.hideCover();
  beginStory();
  ui.showTip('移动鼠标拨动星尘 · 快速划过烛火即可吹灭', 5000);
}

/** 启用手势；任何失败都静默降级，绝不阻断流程 */
async function enableHands() {
  if (state.handsReady) return true;
  try {
    handInput = new HandInput({
      video: document.getElementById('cam'),
      overlay: document.getElementById('hand-overlay'),
      onStatus: (s) => ui.setCamHint(s),
    });
    await handInput.init();
    await handInput.start();
    state.handsReady = true;
    state.handMode = true;
    ui.setCamVisible(true);
    ui.setHandsState(true);
    ui.setCamLive(true);
    ui.setCamHint('张开手掌，拨动星尘');
    ui.showTip('张开手掌拨动星尘 · 捏合指尖吹灭烛火', 5200);
    return true;
  } catch (err) {
    console.warn('[hands] unavailable:', err);
    if (handInput) {
      handInput.dispose();
      handInput = null;
    }
    state.handsReady = false;
    state.handMode = false;
    ui.setCamVisible(false);
    ui.setHandsState(false);
    return false;
  }
}

function beginStory() {
  state.running = true;
  state.chapter = 0;
  state.candlesOut = 0;
  state.celebrateDone = false;
  state.blowCharge = 0;
  state.blowCooldown = 0;
  world.setChapter(0);
  world.celebrateAmount = 0;
  ui.setChapter(0);
  photos.setVisible(true);
  sfx.whoosh(true);
  scheduleAutoAdvance(1);
}

/**
 * 自动推进到下一章。
 * 若用户在等待期间手动切了章，则取消自动推进，尊重用户选择。
 */
function scheduleAutoAdvance(next) {
  clearTimeout(state._autoTimer);
  if (next >= CHAPTERS.length) return;
  state._autoTimer = setTimeout(() => {
    if (state.chapter === next - 1) goChapter(next);
  }, 6200);
}

/* ------------------------------------------------------ 章节推进 */
function goChapter(i) {
  if (i < 0 || i >= CHAPTERS.length) return;
  if (i === state.chapter) return;

  // 手动跳转取消待触发的自动推进
  clearTimeout(state._autoTimer);

  const forward = i > state.chapter;
  state.chapter = i;
  world.chapterIndex = i;
  world.setChapter(i);
  ui.setChapter(i);
  sfx.whoosh(forward);
  sfx.arpeggio();

  // 倒回章节时重置庆祝状态
  if (i < 3) {
    state.celebrateDone = false;
    world.stopCelebrationTimers();
    world.celebrateAmount = 0;
  }

  if (i === 2) {
    state.candlesOut = 0;
    state.blowCharge = 0;
    ui.showTip('把手放到烛火旁，轻轻吹一口气', 5600);
  }
  if (i === 3) {
    triggerCelebrate();
  }
}

/* ------------------------------------------------------ 吹灭蜡烛 */
/**
 * @param {object} [forced] 指定要吹灭的蜡烛；缺省自动找最近的一根
 */
function tryBlow(forced) {
  if (state.chapter !== 2) return;
  const target = forced || findNearestCandle();
  if (!target) return;
  if (!world.extinguishCandle(target)) return;

  state.candlesOut += 1;
  state.blowCharge = 0;
  state.blowTarget = null;
  sfx.blow();
  state.blowCooldown = 0.5;

  const left = state.totalCandles - state.candlesOut;
  if (left > 0) {
    ui.toast(`吹灭 ${state.candlesOut} / ${state.totalCandles} · 还剩 ${left} 根`);
    ui.setCamHint(`还剩 ${left} 根蜡烛`);
  } else {
    ui.toast('全部吹灭！');
    ui.hideTip();
    setTimeout(() => goChapter(3), 1100);
  }
}

/**
 * 找到距离给定点最近的、仍在燃烧的蜡烛。
 * @param {{x:number,y:number}} [at] NDC 坐标，缺省用当前输入位置
 */
function findNearestCandle(at, maxDist = 0.16) {
  const hand = state.handMode && handInput ? handInput.getState() : pointerInput.getState();
  const point = at || (hand && hand.active ? hand : null);
  if (!point) return null;

  let best = null;
  let bestDist = maxDist; // NDC 半径阈值

  world.candles.forEach((c) => {
    if (!c.lit) return;
    // 用火焰网格自身的世界矩阵取位置（不能用 trail 的 position 属性数组）
    c.flame.updateWorldMatrix(true, false);
    const p = new THREE.Vector3();
    c.flame.getWorldPosition(p);
    const proj = p.clone().project(world.camera);
    const d = Math.hypot(proj.x - point.x, proj.y - point.y);
    if (d < bestDist) {
      bestDist = d;
      best = c;
      best.screenDist = d;
    }
  });
  return best;
}

/**
 * 蓄力吹气：指针停在烛火旁不动时，烛焰会逐渐膨胀发亮，
 * 攒满即吹灭。这样「不会快速划动」的寿星也能顺利完成仪式。
 *
 * 蓄力一旦开始就锁定目标蜡烛 —— 相机视差会让烛焰在屏幕上轻微漂移，
 * 若每帧重新找最近的一根，蓄力会反复中断或锁定到别的蜡烛上。
 */
const CHARGE_TIME = 0.95;   // 攒满所需秒数
const CHARGE_GAIN = 1.35;   // 距离越近涨得越快
const CHARGE_KEEP = 0.26;   // 锁定后允许的最大偏移（比命中半径宽松）

function updateBlowCharge(dt, point) {
  // 未被锁定的蜡烛蓄力自然回落
  world.candles.forEach((c) => { c.charge = 0; });

  if (state.chapter !== 2 || state.blowCooldown > 0) {
    state.blowCharge = 0;
    state.blowTarget = null;
    return;
  }
  if (!point || !point.active) {
    state.blowCharge = 0;
    state.blowTarget = null;
    return;
  }

  // 已锁定：只要指针没离开这根蜡烛，就继续蓄力
  let target = state.blowTarget;
  if (target && (!target.lit || target.screenDist > CHARGE_KEEP)) {
    target = null;
    state.blowTarget = null;
    state.blowCharge = 0;
  }

  if (!target) {
    target = findNearestCandle(point);
    if (!target) {
      state.blowCharge = Math.max(0, state.blowCharge - dt * 2.2);
      return;
    }
    state.blowTarget = target;
  } else {
    // 重新测距（烛焰会随相机视差漂移）
    target.flame.updateWorldMatrix(true, false);
    const p = new THREE.Vector3();
    target.flame.getWorldPosition(p);
    const proj = p.clone().project(world.camera);
    target.screenDist = Math.hypot(proj.x - point.x, proj.y - point.y);
  }

  // 距离越近蓄力越快：边缘几乎不涨，正上方最快
  const prox = 1 - Math.min(1, target.screenDist / 0.16);
  state.blowCharge = Math.min(
    CHARGE_TIME,
    state.blowCharge + dt * CHARGE_GAIN * (0.25 + prox * prox * 1.4)
  );

  target.charge = state.blowCharge / CHARGE_TIME;

  if (state.blowCharge >= CHARGE_TIME) {
    state.blowCharge = 0;
    state.blowTarget = null;
    tryBlow(target);
  }
}

/* ------------------------------------------------------ 庆祝 */
function triggerCelebrate() {
  if (state.celebrateDone) return;
  state.celebrateDone = true;
  world.celebrate();
  sfx.boom();
  setTimeout(() => sfx.chime(1046.5), 420);
  setTimeout(() => sfx.chime(1318.5), 640);
  photos.setVisible(false);

  // 结尾文案：先让烟花炸一会儿，再浮出祝福卡片
  const msg = state.msg || '愿这一岁，所有喜欢都如期而至，所有等待都有回响。';
  document.getElementById('finale-text').textContent = msg;
  setTimeout(() => {
    ui.showFinale();
    // 结局画面期间屏蔽底层交互，避免点到被遮挡的按钮
    document.getElementById('app').classList.add('is-finale');
  }, 2600);
}

/* ------------------------------------------------------ 塑形彩蛋 */
function tryShape(pinch) {
  if (!pinch) return;
  if (state.shapeCooldown > 0) return;
  state.shapeCooldown = 2.6;
  world.overlayShape(state._shapeFlip ? 'star' : 'heart');
  state._shapeFlip = !state._shapeFlip;
  sfx.chime(1174.66);
  ui.showTip(state._shapeFlip ? '心形已收拢' : '星星已收拢', 2200);
  setTimeout(() => world.restoreShape(), 2600);
}

/* ------------------------------------------------------ 重开 */
function restart() {
  state.chapter = 0;
  state.candlesOut = 0;
  state.celebrateDone = false;
  state._shapeFlip = false;
  state.blowCharge = 0;
  state.blowCooldown = 0;
  world.stopCelebrationTimers();
  world.celebrateAmount = 0;
  world.chapterIndex = 0;
  world.setChapter(0);
  world.trail.clear();
  ui.hideFinale();
  document.getElementById('app').classList.remove('is-finale');
  ui.setChapter(0);
  photos.setVisible(true);
  sfx.whoosh(true);
  scheduleAutoAdvance(1);
}

/* ------------------------------------------------------ 主循环 */
let last = performance.now();
function loop() {
  requestAnimationFrame(loop);
  const now = performance.now();
  const rawDt = (now - last) / 1000;
  // dt 用于物理/插值，clamp 上限防止切后台回来时跳变
  const dt = Math.min(rawDt, 0.05);
  // realDt 是真实经过时间：低帧率设备上（软件渲染 / 集显），
  // 累加式逻辑若用 clamp 后的 dt 会比真实时间慢很多
  const realDt = Math.min(rawDt, 0.25);
  last = now;
  // elapsed 用真实时间，动画节奏不随帧率漂移（低帧率设备上尤其重要）
  const elapsed = now / 1000;

  if (!world) return;

  state.shapeCooldown = Math.max(0, state.shapeCooldown - realDt);
  state.blowCooldown = Math.max(0, state.blowCooldown - realDt);

  // 手势优先，其次指针
  const handState = state.handMode && handInput ? handInput.getState() : null;
  const ptrState = pointerInput.getState();
  const active = handState || ptrState;

  if (handState) {
    world.applyHand(handState, dt);
    world.parallaxTarget.set(handState.x * 0.5, handState.y * 0.4);
    if (state.chapter === 2 && state.blowCooldown === 0) {
      // 张开手掌靠近烛火 = 吹气
      const near = findNearestCandle(handState);
      if (handState.open && near) tryBlow(near);
    }
    tryShape(handState.pinch);
  } else {
    world.applyPointer(ptrState.x, ptrState.y, dt);
    pointerInput.update(realDt, (ndc) => {
      if (state.chapter !== 2 || state.blowCooldown > 0) return null;
      return findNearestCandle(ndc);
    });
    // 蓄力吹气：指针停在烛火旁不动也能吹灭
    updateBlowCharge(realDt, ptrState);
  }

  world.update(dt, realDt);
  world.render();

  photos.update(world.elapsed, window.innerWidth, window.innerHeight);
}

/* ------------------------------------------------------ 启动 */
init().catch((err) => {
  console.error(err);
  ui.setLoader('加载失败，请刷新重试');
});

/* ------------------------------------------------------ 签名素材 */
probeAssetsQuietly([SIGNATURE.src]).then(([url]) => {
  if (!url) return;
  const sign = document.getElementById('finale-sign');
  const img = document.createElement('img');
  img.src = url;
  img.alt = '签名';
  img.style.maxHeight = '54px';
  img.style.display = 'block';
  img.style.margin = '0 auto 12px';
  sign.parentNode.insertBefore(img, sign);
});
