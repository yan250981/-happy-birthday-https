/**
 * WebAudio 实时合成音效，零音频文件。
 * - 吹气：滤波噪声爆发
 * - 蜡烛点亮：短促铃音
 * - 烟花：低频轰鸣 + 高频碎响
 * - 粒子聚合：柔和的扫频
 */
export class Sfx {
  constructor() {
    this.ctx = null;
    this.master = null;
    this.muted = false;
    this._noiseBuf = null;
  }

  /** 必须由用户手势触发 */
  unlock() {
    if (this.ctx) {
      if (this.ctx.state === 'suspended') this.ctx.resume();
      return;
    }
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return;
    this.ctx = new AC();
    this.master = this.ctx.createGain();
    this.master.gain.value = this.muted ? 0 : 0.5;
    this.master.connect(this.ctx.destination);
    this._buildNoise();
  }

  setMuted(m) {
    this.muted = m;
    if (this.master) {
      this.master.gain.setTargetAtTime(m ? 0 : 0.5, this.ctx.currentTime, 0.05);
    }
  }

  _buildNoise() {
    const len = this.ctx.sampleRate * 2;
    const buf = this.ctx.createBuffer(1, len, this.ctx.sampleRate);
    const d = buf.getChannelData(0);
    for (let i = 0; i < len; i += 1) d[i] = Math.random() * 2 - 1;
    this._noiseBuf = buf;
  }

  _now() {
    return this.ctx ? this.ctx.currentTime : 0;
  }

  /** 吹气：带通噪声 + 快速衰减 */
  blow() {
    if (!this.ctx || this.muted) return;
    const t = this._now();
    const src = this.ctx.createBufferSource();
    src.buffer = this._noiseBuf;
    src.loop = true;

    const bp = this.ctx.createBiquadFilter();
    bp.type = 'bandpass';
    bp.frequency.setValueAtTime(1500, t);
    bp.frequency.exponentialRampToValueAtTime(420, t + 0.42);
    bp.Q.value = 1.1;

    const g = this.ctx.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(0.32, t + 0.05);
    g.gain.exponentialRampToValueAtTime(0.0001, t + 0.5);

    src.connect(bp).connect(g).connect(this.master);
    src.start(t);
    src.stop(t + 0.55);
  }

  /** 蜡烛点亮：清脆铃音 */
  chime(freq = 880) {
    if (!this.ctx || this.muted) return;
    const t = this._now();
    [1, 2.01, 3.02].forEach((mult, i) => {
      const o = this.ctx.createOscillator();
      o.type = 'sine';
      o.frequency.value = freq * mult;
      const g = this.ctx.createGain();
      const amp = 0.12 / (i + 1);
      g.gain.setValueAtTime(0.0001, t);
      g.gain.exponentialRampToValueAtTime(amp, t + 0.012);
      g.gain.exponentialRampToValueAtTime(0.0001, t + 0.9 - i * 0.2);
      o.connect(g).connect(this.master);
      o.start(t);
      o.stop(t + 1);
    });
  }

  /** 粒子聚合：柔和扫频 */
  whoosh(up = true) {
    if (!this.ctx || this.muted) return;
    const t = this._now();
    const src = this.ctx.createBufferSource();
    src.buffer = this._noiseBuf;
    src.loop = true;
    const lp = this.ctx.createBiquadFilter();
    lp.type = 'lowpass';
    lp.frequency.setValueAtTime(up ? 300 : 2600, t);
    lp.frequency.exponentialRampToValueAtTime(up ? 2600 : 300, t + 0.8);
    const g = this.ctx.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(0.1, t + 0.2);
    g.gain.exponentialRampToValueAtTime(0.0001, t + 0.85);
    src.connect(lp).connect(g).connect(this.master);
    src.start(t);
    src.stop(t + 0.9);
  }

  /** 烟花：低频轰鸣 + 高频碎响 */
  boom() {
    if (!this.ctx || this.muted) return;
    const t = this._now();

    const src = this.ctx.createBufferSource();
    src.buffer = this._noiseBuf;
    const lp = this.ctx.createBiquadFilter();
    lp.type = 'lowpass';
    lp.frequency.setValueAtTime(900, t);
    lp.frequency.exponentialRampToValueAtTime(120, t + 1.1);
    const g = this.ctx.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(0.26, t + 0.04);
    g.gain.exponentialRampToValueAtTime(0.0001, t + 1.2);
    src.connect(lp).connect(g).connect(this.master);
    src.start(t);
    src.stop(t + 1.3);

    for (let i = 0; i < 7; i += 1) {
      const d = 0.05 + Math.random() * 0.4;
      const o = this.ctx.createOscillator();
      o.type = 'triangle';
      o.frequency.value = 1200 + Math.random() * 2400;
      const og = this.ctx.createGain();
      og.gain.setValueAtTime(0.0001, t + d);
      og.gain.exponentialRampToValueAtTime(0.045, t + d + 0.008);
      og.gain.exponentialRampToValueAtTime(0.0001, t + d + 0.16);
      o.connect(og).connect(this.master);
      o.start(t + d);
      o.stop(t + d + 0.2);
    }
  }

  /** 音阶上行：章节推进 */
  arpeggio() {
    if (!this.ctx || this.muted) return;
    const t = this._now();
    const notes = [523.25, 659.25, 783.99, 1046.5];
    notes.forEach((f, i) => {
      const o = this.ctx.createOscillator();
      o.type = 'triangle';
      o.frequency.value = f;
      const g = this.ctx.createGain();
      const st = t + i * 0.1;
      g.gain.setValueAtTime(0.0001, st);
      g.gain.exponentialRampToValueAtTime(0.075, st + 0.02);
      g.gain.exponentialRampToValueAtTime(0.0001, st + 0.55);
      o.connect(g).connect(this.master);
      o.start(st);
      o.stop(st + 0.6);
    });
  }
}
