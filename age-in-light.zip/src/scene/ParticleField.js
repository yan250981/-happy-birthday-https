import * as THREE from 'three';
import {
  PARTICLE_VERT,
  PARTICLE_FRAG,
  DUST_VERT,
  DUST_FRAG,
  FIREWORK_VERT,
  FIREWORK_FRAG,
  CONFETTI_VERT,
  CONFETTI_FRAG,
  TRAIL_VERT,
  TRAIL_FRAG,
} from './shaders.js';

/**
 * 主体粒子场。
 * 所有形态共享同一批粒子，GPU 顶点着色器在 aTargetA / aTargetB 之间插值，
 * 因此「散落的星 → 生日快乐 → 蛋糕 → 心形」是一条连续的动作，而非硬切。
 */
export class ParticleField {
  constructor(count = 26000) {
    this.count = count;
    this.morph = 0;
    this.morphFrom = 0;
    this.morphTo = 1;
    this.morphDuration = 2.4;
    this.handForce = 0;

    const geo = new THREE.BufferGeometry();
    const pos = new Float32Array(count * 3);
    const aTargetA = new Float32Array(count * 3);
    const aTargetB = new Float32Array(count * 3);
    const aMorph = new Float32Array(count);
    const aSeed = new Float32Array(count);
    const aSize = new Float32Array(count);
    const aColor = new Float32Array(count * 3);

    const palette = [
      [1.0, 0.84, 0.62],  // 暖金
      [1.0, 0.62, 0.78],  // 玫瑰
      [0.69, 0.55, 1.0],  // 紫罗兰
      [0.56, 0.85, 1.0],  // 冷蓝
      [1.0, 0.95, 0.86],  // 近白
    ];

    for (let i = 0; i < count; i += 1) {
      aMorph[i] = Math.random();
      aSeed[i] = Math.random();
      // 参考站的粒子是「细密锐利的星点」，而不是大团光斑：
      // 绝大多数粒子很小，少量较大做亮点，视觉更接近真实星尘
      const r = Math.random();
      aSize[i] = r < 0.82 ? 0.5 + Math.random() * 1.0 : 1.5 + Math.random() * 2.4;
      const p = palette[(Math.random() * palette.length) | 0];
      const dim = 0.55 + Math.random() * 0.45;
      aColor[i * 3] = p[0] * dim;
      aColor[i * 3 + 1] = p[1] * dim;
      aColor[i * 3 + 2] = p[2] * dim;
    }

    geo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
    geo.setAttribute('aTargetA', new THREE.BufferAttribute(aTargetA, 3));
    geo.setAttribute('aTargetB', new THREE.BufferAttribute(aTargetB, 3));
    geo.setAttribute('aMorph', new THREE.BufferAttribute(aMorph, 1));
    geo.setAttribute('aSeed', new THREE.BufferAttribute(aSeed, 1));
    geo.setAttribute('aSize', new THREE.BufferAttribute(aSize, 1));
    geo.setAttribute('aColor', new THREE.BufferAttribute(aColor, 3));
    geo.boundingSphere = new THREE.Sphere(new THREE.Vector3(), 14);

    this.uniforms = {
      uTime: { value: 0 },
      uMorphProgress: { value: 1 },
      uHandPos: { value: new THREE.Vector3(0, 0, 0) },
      uHandRadius: { value: 1.5 },
      uHandForce: { value: 0 },
      uOrbit: { value: 0.05 },
      uPixelRatio: { value: Math.min(window.devicePixelRatio, 2) },
      uBreath: { value: 1 },
    };

    this.material = new THREE.ShaderMaterial({
      uniforms: this.uniforms,
      vertexShader: PARTICLE_VERT,
      fragmentShader: PARTICLE_FRAG,
      transparent: true,
      depthWrite: false,
      blending: THREE.AdditiveBlending,
    });

    this.points = new THREE.Points(geo, this.material);
    this.points.frustumCulled = false;
    this.geometry = geo;
  }

  /**
   * 切换到新形态：从当前形态平滑过渡到 targets。
   *
   * 关键点：着色器里每个粒子的实际混合进度是
   *   local = smoothstep(clamp((uMorphProgress - aMorph*0.18) / 0.82))
   * 各粒子并不同步，因此冻结起点时必须逐粒子按各自的 local 还原，
   * 否则中途切换会导致形态错位（表现为永远停在半路）。
   */
  setTarget(targets, duration = 2.4) {
    const attrA = this.geometry.getAttribute('aTargetA');
    const attrB = this.geometry.getAttribute('aTargetB');
    const aMorph = this.geometry.getAttribute('aMorph');
    const p = this.uniforms.uMorphProgress.value;

    // 逐粒子还原当前实际位置作为新起点
    const from = attrA.array;
    const to = attrB.array;
    for (let i = 0; i < this.count; i += 1) {
      const local = Math.min(1, Math.max(0, (p - aMorph.array[i] * 0.18) / 0.82));
      const e = local * local * (3 - 2 * local);
      const x = from[i * 3] + (to[i * 3] - from[i * 3]) * e;
      const y = from[i * 3 + 1] + (to[i * 3 + 1] - from[i * 3 + 1]) * e;
      const z = from[i * 3 + 2] + (to[i * 3 + 2] - from[i * 3 + 2]) * e;
      from[i * 3] = x;
      from[i * 3 + 1] = y;
      from[i * 3 + 2] = z;
    }
    attrA.needsUpdate = true;

    attrB.array.set(targets);
    attrB.needsUpdate = true;

    // 用真实时间戳驱动进度：低帧率设备上过渡时长依然准确
    this.morph = 0;
    this.morphStart = performance.now() / 1000;
    this.morphDuration = duration;
    this.uniforms.uMorphProgress.value = 0;
  }

  update(dt, elapsed) {
    this.uniforms.uTime.value = elapsed;
    if (this.morph < 1) {
      const raw = (performance.now() / 1000 - this.morphStart) / this.morphDuration;
      this.morph = Math.min(1, Math.max(0, raw));
      // 用同一份进度驱动，保证 uMorphProgress 与 this.morph 永远一致
      this.uniforms.uMorphProgress.value = this.morph * this.morph * (3 - 2 * this.morph);
    } else {
      this.uniforms.uMorphProgress.value = 1;
    }
    // 手部斥力平滑回零
    this.uniforms.uHandForce.value +=
      (this.handForce - this.uniforms.uHandForce.value) * Math.min(1, dt * 6);
  }

  setHand(worldPos, radius = 1.6, force = 0) {
    this.uniforms.uHandPos.value.copy(worldPos);
    this.uniforms.uHandRadius.value = radius;
    this.handForce = force;
  }

  dispose() {
    this.geometry.dispose();
    this.material.dispose();
  }
}

/** 环境星尘：远景微粒，纯装饰 */
export class StarDust {
  constructor(count = 1400) {
    const geo = new THREE.BufferGeometry();
    const pos = new Float32Array(count * 3);
    const seed = new Float32Array(count);
    const size = new Float32Array(count);
    const color = new Float32Array(count * 3);
    const palette = [
      [1.0, 0.86, 0.66],
      [0.72, 0.6, 1.0],
      [1.0, 0.66, 0.8],
    ];
    for (let i = 0; i < count; i += 1) {
      const r = 9 + Math.random() * 16;
      const theta = Math.random() * Math.PI * 2;
      const phi = Math.acos(2 * Math.random() - 1);
      pos[i * 3] = r * Math.sin(phi) * Math.cos(theta);
      pos[i * 3 + 1] = r * Math.cos(phi) * 0.7;
      pos[i * 3 + 2] = r * Math.sin(phi) * Math.sin(theta);
      seed[i] = Math.random();
      size[i] = 0.5 + Math.random() * 1.8;
      const p = palette[(Math.random() * palette.length) | 0];
      const d = 0.4 + Math.random() * 0.5;
      color[i * 3] = p[0] * d;
      color[i * 3 + 1] = p[1] * d;
      color[i * 3 + 2] = p[2] * d;
    }
    geo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
    geo.setAttribute('aSeed', new THREE.BufferAttribute(seed, 1));
    geo.setAttribute('aSize', new THREE.BufferAttribute(size, 1));
    geo.setAttribute('aColor', new THREE.BufferAttribute(color, 3));

    this.uniforms = {
      uTime: { value: 0 },
      uPixelRatio: { value: Math.min(window.devicePixelRatio, 2) },
    };
    this.material = new THREE.ShaderMaterial({
      uniforms: this.uniforms,
      vertexShader: DUST_VERT,
      fragmentShader: DUST_FRAG,
      transparent: true,
      depthWrite: false,
      blending: THREE.AdditiveBlending,
    });
    this.points = new THREE.Points(geo, this.material);
    this.points.frustumCulled = false;
  }

  update(elapsed) {
    this.uniforms.uTime.value = elapsed;
  }
}

/** 烟花：预分配池，发射时写入属性 */
export class Fireworks {
  constructor(capacity = 2400) {
    this.capacity = capacity;
    this.cursor = 0;
    const geo = new THREE.BufferGeometry();
    const pos = new Float32Array(capacity * 3);
    const vel = new Float32Array(capacity * 3);
    const color = new Float32Array(capacity * 3);
    const start = new Float32Array(capacity).fill(-999);
    const life = new Float32Array(capacity).fill(1);
    const size = new Float32Array(capacity).fill(2);
    const seed = new Float32Array(capacity);

    geo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
    geo.setAttribute('aVel', new THREE.BufferAttribute(vel, 3));
    geo.setAttribute('aColor', new THREE.BufferAttribute(color, 3));
    geo.setAttribute('aStart', new THREE.BufferAttribute(start, 1));
    geo.setAttribute('aLife', new THREE.BufferAttribute(life, 1));
    geo.setAttribute('aSize', new THREE.BufferAttribute(size, 1));
    geo.setAttribute('aSeed', new THREE.BufferAttribute(seed, 1));
    geo.boundingSphere = new THREE.Sphere(new THREE.Vector3(), 40);

    this.uniforms = {
      uTime: { value: 0 },
      uPixelRatio: { value: Math.min(window.devicePixelRatio, 2) },
    };
    this.material = new THREE.ShaderMaterial({
      uniforms: this.uniforms,
      vertexShader: FIREWORK_VERT,
      fragmentShader: FIREWORK_FRAG,
      transparent: true,
      depthWrite: false,
      blending: THREE.AdditiveBlending,
    });
    this.points = new THREE.Points(geo, this.material);
    this.points.frustumCulled = false;
    this.geometry = geo;
  }

  burst(center, palette, now, count = 190, speed = 3.4) {
    const pos = this.geometry.getAttribute('position');
    const vel = this.geometry.getAttribute('aVel');
    const color = this.geometry.getAttribute('aColor');
    const start = this.geometry.getAttribute('aStart');
    const life = this.geometry.getAttribute('aLife');
    const size = this.geometry.getAttribute('aSize');
    const seed = this.geometry.getAttribute('aSeed');

    for (let n = 0; n < count; n += 1) {
      const i = this.cursor;
      this.cursor = (this.cursor + 1) % this.capacity;
      const theta = Math.random() * Math.PI * 2;
      const phi = Math.acos(2 * Math.random() - 1);
      const sp = speed * (0.45 + Math.random() * 0.75);
      pos.array[i * 3] = center.x + (Math.random() - 0.5) * 0.2;
      pos.array[i * 3 + 1] = center.y + (Math.random() - 0.5) * 0.2;
      pos.array[i * 3 + 2] = center.z + (Math.random() - 0.5) * 0.2;
      vel.array[i * 3] = Math.sin(phi) * Math.cos(theta) * sp;
      vel.array[i * 3 + 1] = Math.cos(phi) * sp * 0.92 + 0.5;
      vel.array[i * 3 + 2] = Math.sin(phi) * Math.sin(theta) * sp;
      const c = palette[(Math.random() * palette.length) | 0];
      color.array[i * 3] = c[0];
      color.array[i * 3 + 1] = c[1];
      color.array[i * 3 + 2] = c[2];
      start.array[i] = now;
      life.array[i] = 1.5 + Math.random() * 1.3;
      size.array[i] = 1.4 + Math.random() * 3.4;
      seed.array[i] = Math.random();
    }
    pos.needsUpdate = vel.needsUpdate = color.needsUpdate = true;
    start.needsUpdate = life.needsUpdate = size.needsUpdate = seed.needsUpdate = true;
  }

  update(elapsed) {
    this.uniforms.uTime.value = elapsed;
  }
}

/** 彩带：庆祝时从顶部飘落 */
export class Confetti {
  constructor(capacity = 900) {
    const geo = new THREE.BufferGeometry();
    const pos = new Float32Array(capacity * 3);
    const vel = new Float32Array(capacity * 3);
    const color = new Float32Array(capacity * 3);
    const start = new Float32Array(capacity).fill(-999);
    const seed = new Float32Array(capacity);
    const size = new Float32Array(capacity);

    geo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
    geo.setAttribute('aVel', new THREE.BufferAttribute(vel, 3));
    geo.setAttribute('aColor', new THREE.BufferAttribute(color, 3));
    geo.setAttribute('aStart', new THREE.BufferAttribute(start, 1));
    geo.setAttribute('aSeed', new THREE.BufferAttribute(seed, 1));
    geo.setAttribute('aSize', new THREE.BufferAttribute(size, 1));
    geo.boundingSphere = new THREE.Sphere(new THREE.Vector3(), 30);

    this.uniforms = {
      uTime: { value: 0 },
      uPixelRatio: { value: Math.min(window.devicePixelRatio, 2) },
    };
    this.material = new THREE.ShaderMaterial({
      uniforms: this.uniforms,
      vertexShader: CONFETTI_VERT,
      fragmentShader: CONFETTI_FRAG,
      transparent: true,
      depthWrite: false,
      blending: THREE.AdditiveBlending,
    });
    this.points = new THREE.Points(geo, this.material);
    this.points.frustumCulled = false;
    this.geometry = geo;
  }

  drop(now, count = 260) {
    const pos = this.geometry.getAttribute('position');
    const vel = this.geometry.getAttribute('aVel');
    const color = this.geometry.getAttribute('color');
    const start = this.geometry.getAttribute('aStart');
    const seed = this.geometry.getAttribute('aSeed');
    const size = this.geometry.getAttribute('aSize');
    const palette = [
      [1.0, 0.82, 0.55],
      [1.0, 0.58, 0.76],
      [0.68, 0.56, 1.0],
      [0.6, 0.86, 1.0],
    ];
    void color;
    for (let n = 0; n < count; n += 1) {
      const i = n % this.capacity;
      pos.array[i * 3] = (Math.random() - 0.5) * 9;
      pos.array[i * 3 + 1] = 5 + Math.random() * 2.5;
      pos.array[i * 3 + 2] = (Math.random() - 0.5) * 4;
      vel.array[i * 3] = (Math.random() - 0.5) * 0.5;
      vel.array[i * 3 + 2] = (Math.random() - 0.5) * 0.4;
      const c = palette[(Math.random() * palette.length) | 0];
      const a = this.geometry.getAttribute('aColor');
      a.array[i * 3] = c[0];
      a.array[i * 3 + 1] = c[1];
      a.array[i * 3 + 2] = c[2];
      start.array[i] = now + Math.random() * 2.2;
      seed.array[i] = Math.random();
      size.array[i] = 4 + Math.random() * 5;
    }
    pos.needsUpdate = vel.needsUpdate = start.needsUpdate = seed.needsUpdate = size.needsUpdate = true;
    this.geometry.getAttribute('aColor').needsUpdate = true;
  }

  update(elapsed) {
    this.uniforms.uTime.value = elapsed;
  }
}

/** 手部轨迹拖尾：环形缓冲的亮点串 */
export class Trail {
  constructor(length = 46) {
    this.length = length;
    this.cursor = 0;
    const geo = new THREE.BufferGeometry();
    const pos = new Float32Array(length * 3);
    const life = new Float32Array(length);
    const color = new Float32Array(length * 3);
    const size = new Float32Array(length);
    for (let i = 0; i < length; i += 1) {
      size[i] = 3 + Math.random() * 4;
      color[i * 3] = 1.0;
      color[i * 3 + 1] = 0.82;
      color[i * 3 + 2] = 0.6;
    }
    geo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
    geo.setAttribute('aLife', new THREE.BufferAttribute(life, 1));
    geo.setAttribute('aColor', new THREE.BufferAttribute(color, 3));
    geo.setAttribute('aSize', new THREE.BufferAttribute(size, 1));
    geo.boundingSphere = new THREE.Sphere(new THREE.Vector3(), 20);

    this.uniforms = {
      uPixelRatio: { value: Math.min(window.devicePixelRatio, 2) },
    };
    this.material = new THREE.ShaderMaterial({
      uniforms: this.uniforms,
      vertexShader: TRAIL_VERT,
      fragmentShader: TRAIL_FRAG,
      transparent: true,
      depthWrite: false,
      blending: THREE.AdditiveBlending,
    });
    this.points = new THREE.Points(geo, this.material);
    this.points.frustumCulled = false;
    this.geometry = geo;
    this.age = new Float32Array(length);
  }

  push(x, y, z) {
    const pos = this.geometry.getAttribute('position');
    const life = this.geometry.getAttribute('aLife');
    const i = this.cursor;
    this.cursor = (this.cursor + 1) % this.length;
    pos.array[i * 3] = x;
    pos.array[i * 3 + 1] = y;
    pos.array[i * 3 + 2] = z;
    this.age[i] = 1;
    life.array[i] = 1;
    pos.needsUpdate = true;
    life.needsUpdate = true;
  }

  update(dt) {
    const life = this.geometry.getAttribute('aLife');
    let dirty = false;
    for (let i = 0; i < this.length; i += 1) {
      if (this.age[i] > 0) {
        this.age[i] = Math.max(0, this.age[i] - dt * 1.25);
        life.array[i] = this.age[i] * this.age[i];
        dirty = true;
      }
    }
    if (dirty) life.needsUpdate = true;
  }

  clear() {
    this.age.fill(0);
    this.geometry.getAttribute('aLife').array.fill(0);
    this.geometry.getAttribute('aLife').needsUpdate = true;
  }
}
