import * as THREE from 'three';

/**
 * 形态生成器 —— 每个返回 count 个三维目标坐标（Float32Array，长度 count*3）。
 * 所有粒子在所有形态间保持同一 index，从而在 GPU 上连续形变。
 */

/* 确定性随机数，保证每次刷新形态一致 */
export function mulberry32(seed) {
  let a = seed >>> 0;
  return function () {
    a |= 0; a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const rand = mulberry32(20261110);

/* ------------------------------------------------------------------ 文字 */
const textCache = new Map();

/**
 * 把文字采样成粒子点阵：离屏画布绘制 → 读取 alpha 通道 → 随机取点 + 抖动。
 * 使用 alpha 通道而非 RGB，避免抗锯齿边缘的暗像素被误判。
 */
export function textPoints(text, count, opts = {}) {
  const key = `${text}|${count}|${opts.size || 0}|${opts.scale || 0}`;
  if (textCache.has(key)) return textCache.get(key);

  const size = opts.size || 160;
  const width = 1600;
  const height = 460;
  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d', { willReadFrequently: true });

  ctx.fillStyle = '#000';
  ctx.fillRect(0, 0, width, height);
  ctx.font = `500 ${size}px "Songti SC", "STSong", "Noto Serif CJK SC", "Source Han Serif SC", "Microsoft YaHei", serif`;
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillStyle = '#fff';
  ctx.fillText(text, width / 2, height / 2 + size * 0.04, width * 0.94);

  const img = ctx.getImageData(0, 0, width, height);
  const data = img.data;

  // 收集笔画内部像素（alpha > 128 且亮度足够）
  const solid = [];
  for (let y = 0; y < height; y += 1) {
    for (let x = 0; x < width; x += 1) {
      const i = (y * width + x) * 4;
      if (data[i + 3] > 120 && data[i] > 90) solid.push(x, y);
    }
  }

  const out = new Float32Array(count * 3);
  const total = solid.length / 2;
  const scale = opts.scale ?? 0.0115;
  const cx = width / 2;
  const cy = height / 2;

  if (total === 0) {
    // 字体不可用时的兜底：排成一行方块，至少不空场
    for (let i = 0; i < count; i += 1) {
      const col = i % 12;
      const row = Math.floor(i / 12) % 12;
      out[i * 3] = (col - 5.5) * 0.42;
      out[i * 3 + 1] = (row - 5.5) * 0.42;
      out[i * 3 + 2] = (rand() - 0.5) * 0.2;
    }
    textCache.set(key, out);
    return out;
  }

  for (let i = 0; i < count; i += 1) {
    const k = Math.floor(rand() * total) * 2;
    const sx = solid[k] + (rand() - 0.5) * 2.0;
    const sy = solid[k + 1] + (rand() - 0.5) * 2.0;
    out[i * 3] = (sx - cx) * scale;
    out[i * 3 + 1] = -(sy - cy) * scale;
    out[i * 3 + 2] = (rand() - 0.5) * 0.1;
  }

  textCache.set(key, out);
  return out;
}

/* -------------------------------------------------------------- 散落星云 */
export function scatterPoints(count, opts = {}) {
  const spread = opts.spread ?? 7.5;
  const out = new Float32Array(count * 3);
  for (let i = 0; i < count; i += 1) {
    // 球壳 + 内部稀疏
    const r = spread * (0.25 + 0.75 * Math.pow(rand(), 0.55));
    const theta = rand() * Math.PI * 2;
    const phi = Math.acos(2 * rand() - 1);
    out[i * 3] = r * Math.sin(phi) * Math.cos(theta);
    out[i * 3 + 1] = r * Math.cos(phi) * 0.55;
    out[i * 3 + 2] = r * Math.sin(phi) * Math.sin(theta) * 0.6;
  }
  return out;
}

/* ------------------------------------------------------------------ 圆环 */
export function ringPoints(count, opts = {}) {
  const radius = opts.radius ?? 3.2;
  const rings = opts.rings ?? 3;
  const tube = opts.tube ?? 0.09;
  const out = new Float32Array(count * 3);
  for (let i = 0; i < count; i += 1) {
    const ring = i % rings;
    const t = rand() * Math.PI * 2;
    const r = radius * (0.72 + 0.28 * (ring / Math.max(rings - 1, 1)));
    const tilt = (ring / Math.max(rings - 1, 1)) * 0.9 - 0.35;
    const jitter = (rand() - 0.5) * tube;
    const x = Math.cos(t) * (r + jitter);
    const z = Math.sin(t) * (r + jitter);
    const y = Math.sin(t) * 0.0 + (rand() - 0.5) * tube;
    const c = Math.cos(tilt);
    const s = Math.sin(tilt);
    out[i * 3] = x * c - y * s;
    out[i * 3 + 1] = x * s + y * c;
    out[i * 3 + 2] = z;
  }
  return out;
}

/* ------------------------------------------------------------------ 球壳 */
export function spherePoints(count, opts = {}) {
  const radius = opts.radius ?? 2.4;
  const out = new Float32Array(count * 3);
  for (let i = 0; i < count; i += 1) {
    const theta = rand() * Math.PI * 2;
    const phi = Math.acos(2 * rand() - 1);
    const r = radius * (0.9 + 0.12 * rand());
    out[i * 3] = r * Math.sin(phi) * Math.cos(theta);
    out[i * 3 + 1] = r * Math.cos(phi);
    out[i * 3 + 2] = r * Math.sin(phi) * Math.sin(theta);
  }
  return out;
}

/* ------------------------------------------------------ 粒子蛋糕（主体） */
export function cakePoints(count, opts = {}) {
  const out = new Float32Array(count * 3);
  const body = Math.floor(count * 0.68);
  const rings = Math.floor(count * 0.22);
  const halo = count - body - rings;

  const R = opts.radius ?? 1.72;
  const H = opts.height ?? 1.5;

  // 主体：圆柱 + 平顶 + 圆角底，密度集中在表面，读起来才像「一个蛋糕」
  for (let i = 0; i < body; i += 1) {
    const y = (rand() - 0.5) * H;
    const ny = y / (H / 2); // -1..1
    // 顶部收成平面，底部收成圆角
    let radial = 1;
    if (ny > 0.88) radial = Math.sqrt(Math.max(0, 1 - Math.pow((ny - 0.88) / 0.12, 2)));
    if (ny < -0.9) radial = Math.sqrt(Math.max(0, 1 - Math.pow((-ny - 0.9) / 0.1, 2)));
    const r = R * radial * (0.97 + rand() * 0.03);
    const theta = rand() * Math.PI * 2;
    // 92% 贴表面，8% 稍微内嵌制造厚度感
    const depth = rand() < 0.92 ? 1 : 0.9 + rand() * 0.09;
    out[i * 3] = Math.cos(theta) * r * depth;
    out[i * 3 + 1] = y;
    out[i * 3 + 2] = Math.sin(theta) * r * depth;
  }

  // 顶面：密铺一层，呼应参考站「平顶 + 烛台」的结构
  const capCount = Math.floor(body * 0.16);
  for (let i = 0; i < capCount; i += 1) {
    const k = body - capCount + i;
    const theta = rand() * Math.PI * 2;
    const rad = Math.sqrt(rand()) * R * 0.94;
    out[k * 3] = Math.cos(theta) * rad;
    out[k * 3 + 1] = H / 2 - rand() * 0.04;
    out[k * 3 + 2] = Math.sin(theta) * rad;
  }

  // 环绕轨道：三道紧贴蛋糕的倾斜椭圆
  for (let i = 0; i < rings; i += 1) {
    const ring = i % 3;
    const t = rand() * Math.PI * 2;
    const rad = R * (1.32 + ring * 0.3);
    const tilt = 0.16 + ring * 0.16;
    const j = (rand() - 0.5) * 0.12;
    const x = Math.cos(t) * (rad + j);
    const z = Math.sin(t) * (rad + j);
    const y = (rand() - 0.5) * 0.08;
    const c = Math.cos(tilt);
    const s = Math.sin(tilt);
    out[(body + i) * 3] = x * c - y * s;
    out[(body + i) * 3 + 1] = x * s + y * c;
    out[(body + i) * 3 + 2] = z;
  }

  // 顶部飘散（蜡烛周围的新星），范围收窄，避免整体发雾
  for (let i = 0; i < halo; i += 1) {
    const k = body + rings + i;
    const theta = rand() * Math.PI * 2;
    const rad = R * (0.3 + rand() * 0.75);
    out[k * 3] = Math.cos(theta) * rad;
    out[k * 3 + 1] = H / 2 + rand() * 0.75;
    out[k * 3 + 2] = Math.sin(theta) * rad * 0.7;
  }
  return out;
}

/* ------------------------------------------------------------------ 心形 */
export function heartPoints(count, opts = {}) {
  const out = new Float32Array(count * 3);
  const s = opts.scale ?? 0.115;
  for (let i = 0; i < count; i += 1) {
    const t = rand() * Math.PI * 2;
    const x = 16 * Math.pow(Math.sin(t), 3);
    const y = 13 * Math.cos(t) - 5 * Math.cos(2 * t) - 2 * Math.cos(3 * t) - Math.cos(4 * t);
    // 内部填充：往中心收缩一点
    const shrink = 0.62 + rand() * 0.42;
    out[i * 3] = x * s * shrink;
    out[i * 3 + 1] = y * s * shrink * 0.95 + 0.25;
    out[i * 3 + 2] = (rand() - 0.5) * 0.4;
  }
  return out;
}

/* ------------------------------------------------------------------ 星星 */
export function starPoints(count, opts = {}) {
  const out = new Float32Array(count * 3);
  const R = opts.radius ?? 1.9;
  const inner = R * 0.42;
  const points = [];
  for (let i = 0; i < 10; i += 1) {
    const ang = (i / 10) * Math.PI * 2 - Math.PI / 2;
    const rad = i % 2 === 0 ? R : inner;
    points.push(Math.cos(ang) * rad, Math.sin(ang) * rad);
  }
  for (let i = 0; i < count; i += 1) {
    const seg = Math.floor(rand() * 10);
    const nx = points[((seg + 1) % 10) * 2];
    const ny = points[((seg + 1) % 10) * 2 + 1];
    const t = rand();
    const shrink = 0.78 + rand() * 0.3;
    out[i * 3] = (points[seg * 2] + (nx - points[seg * 2]) * t) * shrink;
    out[i * 3 + 1] = (points[seg * 1] + (ny - points[seg * 1]) * t) * shrink * 0.92;
    out[i * 3 + 2] = (rand() - 0.5) * 0.26;
  }
  return out;
}

/* ------------------------------------------------------- 螺旋（吹气扩散） */
export function spiralPoints(count, opts = {}) {
  const out = new Float32Array(count * 3);
  const turns = opts.turns ?? 3.4;
  const maxR = opts.radius ?? 3.4;
  for (let i = 0; i < count; i += 1) {
    const t = rand();
    const ang = t * Math.PI * 2 * turns + rand() * 0.5;
    const rad = 0.5 + t * maxR;
    out[i * 3] = Math.cos(ang) * rad;
    out[i * 3 + 1] = (rand() - 0.5) * 1.2 * (0.4 + t);
    out[i * 3 + 2] = Math.sin(ang) * rad * 0.62;
  }
  return out;
}

/* ------------------------------------------ 绽放形态：稀疏的星尘轨道环 */
export function bloomPoints(count, opts = {}) {
  const out = new Float32Array(count * 3);
  const rings = opts.rings ?? 4;
  const maxR = opts.radius ?? 4.6;
  for (let i = 0; i < count; i += 1) {
    const ring = i % rings;
    const rn = ring / Math.max(rings - 1, 1);
    const t = rand() * Math.PI * 2;
    // 每圈半径不同，略微倾斜，形成层叠的轨道
    const rad = 1.2 + rn * (maxR - 1.2) + (rand() - 0.5) * 0.55;
    const tilt = (rn - 0.5) * 0.8;
    const x = Math.cos(t) * rad;
    const z = Math.sin(t) * rad;
    const y = Math.sin(t * 1.3 + ring) * 0.45 + (rand() - 0.5) * 0.5;
    const c = Math.cos(tilt);
    const s = Math.sin(tilt);
    out[i * 3] = x * c - y * s;
    out[i * 3 + 1] = x * s + y * c;
    out[i * 3 + 2] = z;
  }
  return out;
}
