import * as THREE from 'three';
import { EffectComposer } from 'three/examples/jsm/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/examples/jsm/postprocessing/RenderPass.js';
import { UnrealBloomPass } from 'three/examples/jsm/postprocessing/UnrealBloomPass.js';
import { OutputPass } from 'three/examples/jsm/postprocessing/OutputPass.js';

import { BG_VERT, BG_FRAG, FLAME_VERT, FLAME_FRAG, CAKE_VERT, CAKE_FRAG } from './shaders.js';
import { ParticleField, StarDust, Fireworks, Confetti, Trail } from './ParticleField.js';
import {
  scatterPoints,
  textPoints,
  ringPoints,
  cakePoints,
  heartPoints,
  starPoints,
  bloomPoints,
} from './shapes.js';

/** 章节定义：既是叙事骨架，也是视觉状态机 */
export const CHAPTERS = [
  {
    id: 'prologue',
    index: 'PROLOGUE',
    cn: '序幕',
    title: '散落的星',
    sub: '用手指拂过，星尘会为你让开一条路。',
    caption: '散落的星，还没找到自己的位置。',
    camera: { x: 0, y: 0.6, z: 11.5 },
  },
  {
    id: 'first',
    index: 'CHAPTER I',
    cn: '相遇',
    title: '生日快乐',
    sub: '它们听见了你的名字，于是聚成了四个字。',
    caption: '当星尘拼出这四个字，说明它认识你了。',
    camera: { x: 0, y: 0.3, z: 8.4 },
  },
  {
    id: 'second',
    index: 'CHAPTER II',
    cn: '许愿',
    title: '把愿望放进蛋糕',
    sub: '五根蜡烛，一根一根来。吹灭它们，星尘就会炸开。',
    caption: '把手放到烛火旁，轻轻吹一口气。',
    camera: { x: 0, y: 0.1, z: 7.2 },
  },
  {
    id: 'third',
    index: 'CHAPTER III',
    cn: '绽放',
    title: '这一岁的光',
    sub: '愿望已经送出去了，剩下的交给夜空。',
    caption: '愿望已送达。今晚的夜空，是你的。',
    camera: { x: 0, y: 1.4, z: 13.5 },
  },
];

export class World {
  constructor(canvas, opts = {}) {
    this.canvas = canvas;
    this.quality = opts.quality || 'high';
    this.reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    const counts = {
      high: { particles: 26000, dust: 1500 },
      medium: { particles: 15000, dust: 900 },
      low: { particles: 7000, dust: 500 },
    };
    const c = counts[this.quality] || counts.high;

    /* ---------------- 渲染器 ---------------- */
    this.renderer = new THREE.WebGLRenderer({
      canvas,
      antialias: this.quality === 'high',
      alpha: false,
      powerPreference: 'high-performance',
    });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, this.quality === 'high' ? 2 : 1.5));
    this.renderer.setSize(window.innerWidth, window.innerHeight);
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.05;

    /* ---------------- 场景与相机 ---------------- */
    this.scene = new THREE.Scene();
    this.scene.fog = new THREE.FogExp2(0x05040d, 0.028);

    this.camera = new THREE.PerspectiveCamera(46, window.innerWidth / window.innerHeight, 0.1, 200);
    this.camera.position.set(0, 0.6, 11.5);
    this.camTarget = new THREE.Vector3(0, 0.6, 11.5);
    this.lookTarget = new THREE.Vector3(0, 0, 0);
    // 相机注视点的目标值。lookTarget 向它插值，实现章节切换时的平滑转场。
    // （此前误写成 lookTarget.lerp(lookTarget, …)，自己插值自己等于没插值，
    //   导致注视点在切章时瞬间硬跳。）
    this.lookGoal = new THREE.Vector3(0, 0, 0);
    this.parallax = new THREE.Vector2();
    this.parallaxTarget = new THREE.Vector2();

    /* ---------------- 背景 ---------------- */
    this.bgUniforms = {
      uTime: { value: 0 },
      uCelebrate: { value: 0 },
      uResolution: { value: new THREE.Vector2(window.innerWidth, window.innerHeight) },
    };
    const bg = new THREE.Mesh(
      new THREE.PlaneGeometry(2, 2),
      new THREE.ShaderMaterial({
        uniforms: this.bgUniforms,
        vertexShader: BG_VERT,
        fragmentShader: BG_FRAG,
        depthWrite: false,
        depthTest: false,
      })
    );
    bg.frustumCulled = false;
    bg.renderOrder = -100;
    this.scene.add(bg);

    /* ---------------- 灯光 ---------------- */
    this.scene.add(new THREE.AmbientLight(0x5a4a7a, 0.5));
    const key = new THREE.PointLight(0xffc98a, 2.4, 26, 2);
    key.position.set(0, 4.2, 3.4);
    this.scene.add(key);
    this.keyLight = key;
    const rim = new THREE.PointLight(0x8f6cff, 1.6, 30, 2);
    rim.position.set(-5, -1.6, -4);
    this.scene.add(rim);
    const warm = new THREE.PointLight(0xff8fb8, 1.1, 24, 2);
    warm.position.set(4.5, 1.2, 2.2);
    this.scene.add(warm);

    /* ---------------- 主体粒子 ---------------- */
    this.field = new ParticleField(c.particles);
    this.scene.add(this.field.points);

    this.dust = new StarDust(c.dust);
    this.scene.add(this.dust.points);

    this.fireworks = new Fireworks(2600);
    this.scene.add(this.fireworks.points);

    this.confetti = new Confetti(900);
    this.scene.add(this.confetti.points);

    this.trail = new Trail(46);
    this.scene.add(this.trail.points);

    /* ---------------- 蜡烛（实体，作为粒子蛋糕之上的点缀） ---------------- */
    this.candles = [];
    this.cakeGroup = new THREE.Group();
    this.scene.add(this.cakeGroup);

    /* ---------------- 后期 ---------------- */
    this.composer = new EffectComposer(this.renderer);
    this.composer.addPass(new RenderPass(this.scene, this.camera));
    this.bloom = new UnrealBloomPass(
      new THREE.Vector2(window.innerWidth, window.innerHeight),
      0.52,
      0.5,
      0.32
    );
    this.composer.addPass(this.bloom);
    this.composer.addPass(new OutputPass());

    this.elapsed = 0;
    this.celebrateAmount = 0;
    this._bindResize();
  }

  _bindResize() {
    this.onResize = () => {
      const w = window.innerWidth;
      const h = window.innerHeight;
      this.camera.aspect = w / h;
      this.camera.updateProjectionMatrix();
      this.renderer.setSize(w, h);
      this.composer.setSize(w, h);
      this.bgUniforms.uResolution.value.set(w, h);
      const pr = Math.min(window.devicePixelRatio, this.quality === 'high' ? 2 : 1.5);
      this.field.uniforms.uPixelRatio.value = pr;
      this.dust.uniforms.uPixelRatio.value = pr;
      this.fireworks.uniforms.uPixelRatio.value = pr;
      this.confetti.uniforms.uPixelRatio.value = pr;
      this.trail.uniforms.uPixelRatio.value = pr;
    };
    window.addEventListener('resize', this.onResize);
  }

  /* ---------------------------------------------------------- 章节切换 */
  setChapter(index) {
    const ch = CHAPTERS[index];
    if (!ch) return;
    this.chapter = ch;
    this.camTarget.set(ch.camera.x, ch.camera.y, ch.camera.z);
    this.lookGoal.set(0, ch.id === 'second' ? 0.2 : 0, 0);

    const count = this.field.count;
    if (ch.id === 'prologue') {
      this.field.setTarget(scatterPoints(count, { spread: 7.2 }), 2.6);
      this.field.uniforms.uOrbit.value = 0.06;
      this.field.uniforms.uBreath.value = 1;
      this.buildCandles(0);
    } else if (ch.id === 'first') {
      const t = this.recipientText();
      this.field.setTarget(textPoints(t, count, { size: 200, scale: 0.0068 }), 2.8);
      this.field.uniforms.uOrbit.value = 0.02;
      this.field.uniforms.uBreath.value = 0.6;
      this.buildCandles(0);
    } else if (ch.id === 'second') {
      this.field.setTarget(cakePoints(count, { radius: 1.75, height: 1.5 }), 2.5);
      this.field.uniforms.uOrbit.value = 0.055;
      this.field.uniforms.uBreath.value = 0.8;
      this.buildCandles(5);
    } else if (ch.id === 'third') {
      this.field.setTarget(bloomPoints(count, { radius: 4.6, rings: 4 }), 3.2);
      this.field.uniforms.uOrbit.value = 0.11;
      this.field.uniforms.uBreath.value = 1.2;
      this.buildCandles(0);
    }
  }

  /** 叠加一层形态（心形 / 星星 彩蛋）：把粒子推向新目标再回到当前 */
  overlayShape(kind) {
    const count = this.field.count;
    const targets = kind === 'heart'
      ? heartPoints(count, { scale: 0.115 })
      : starPoints(count, { radius: 1.95 });
    this.field.setTarget(targets, 1.5);
    this._pendingRestore = true;
  }

  restoreShape() {
    if (!this._pendingRestore) return;
    this._pendingRestore = false;
    this.setChapter(this.chapterIndex ?? 0);
  }

  recipientText() {
    return this.recipient ? `生日快乐` : '生日快乐';
  }

  /* ------------------------------------------------------------- 蜡烛 */
  buildCandles(n) {
    this.candles.forEach((c) => {
      this.cakeGroup.remove(c.group);
      c.flame.geometry.dispose();
      c.flame.material.dispose();
      c.body.geometry.dispose();
      c.body.material.dispose();
    });
    this.candles = [];

    if (n === 0) return;

    const geo = new THREE.CylinderGeometry(0.042, 0.05, 0.34, 20);
    const positions = [
      [-0.85, 0.9, 0.35],
      [0.85, 0.9, 0.35],
      [-0.5, 0.9, -0.55],
      [0.5, 0.9, -0.55],
      [0, 0.9, 0.1],
    ];

    for (let i = 0; i < n; i += 1) {
      const group = new THREE.Group();
      const p = positions[i % positions.length];

      const bodyMat = new THREE.ShaderMaterial({
        uniforms: {
          uColorA: { value: new THREE.Color(0xf5e6d0) },
          uColorB: { value: new THREE.Color(0xe8c9a8) },
          uTime: { value: 0 },
          uOpacity: { value: 1 },
        },
        vertexShader: CAKE_VERT,
        fragmentShader: CAKE_FRAG,
        transparent: true,
      });
      const body = new THREE.Mesh(geo, bodyMat);
      group.add(body);

      const flameMat = new THREE.ShaderMaterial({
        uniforms: {
          uTime: { value: 0 },
          uSeed: { value: i * 1.7 + 0.3 },
          uOut: { value: 0 },
          uCharge: { value: 0 },
        },
        vertexShader: FLAME_VERT,
        fragmentShader: FLAME_FRAG,
        transparent: true,
        depthWrite: false,
        blending: THREE.AdditiveBlending,
      });
      const flame = new THREE.Mesh(new THREE.PlaneGeometry(0.16, 0.34), flameMat);
      flame.position.y = 0.32;
      group.add(flame);

      group.position.set(p[0], p[1], p[2]);
      this.cakeGroup.add(group);
      this.candles.push({
        group,
        flame,
        body,
        out: 0,
        charge: 0,
        lit: true,
        index: i,
        worldPos: new THREE.Vector3(p[0], p[1] + 0.3, p[2]),
      });
    }
  }

  /**
   * 熄灭一根蜡烛。
   * @param {object|number} target 蜡烛对象或其在 this.candles 中的索引
   */
  extinguishCandle(target) {
    const c = typeof target === 'number' ? this.candles[target] : target;
    if (!c || !c.lit || !this.candles.includes(c)) return false;
    c.lit = false;
    c.out = 0.0001;
    return true;
  }

  get litCount() {
    return this.candles.filter((c) => c.lit).length;
  }

  /* --------------------------------------------------------- 手势输入 */
  /**
   * @param {object} hand 手势数据 { active, x, y, z, pinch, open }
   * x/y 为 NDC 坐标，z 为深度估计
   */
  applyHand(hand, dt) {
    if (!hand || !hand.active) {
      this.field.setHand(this.field.uniforms.uHandPos.value, 1.6, 0);
      return;
    }
    // NDC → 世界坐标（放在 z=0 平面上）
    const dist = this.camera.position.z;
    const h = 2 * Math.tan((this.camera.fov * Math.PI) / 360) * dist;
    const w = h * this.camera.aspect;
    const wx = hand.x * (w / 2);
    const wy = hand.y * (h / 2);

    const world = new THREE.Vector3(wx, wy, 0);
    const force = hand.open ? 0.55 : 0.28;
    const radius = hand.pinch ? 1.05 : 1.9;

    this.field.setHand(world, radius, force);
    this.trail.push(world.x, world.y, 0.4);
  }

  applyPointer(px, py, dt) {
    const dist = this.camera.position.z;
    const h = 2 * Math.tan((this.camera.fov * Math.PI) / 360) * dist;
    const w = h * this.camera.aspect;
    const wx = px * (w / 2);
    const wy = py * (h / 2);
    const world = new THREE.Vector3(wx, wy, 0);
    this.field.setHand(world, 1.5, 0.3);
    this.trail.push(world.x, world.y, 0.4);
  }

  /* ------------------------------------------------------------ 庆祝 */
  celebrate() {
    this.celebrateAmount = 1;
    const palette = [
      [1.0, 0.8, 0.5],
      [1.0, 0.55, 0.75],
      [0.7, 0.6, 1.0],
      [0.6, 0.88, 1.0],
    ];
    // 连续多轮烟花，覆盖整个庆祝段落，而不是只炸一次
    this._fireworkTimers = [];
    const centers = [
      new THREE.Vector3(-3.6, 3.4, -2),
      new THREE.Vector3(3.8, 2.8, -2.5),
      new THREE.Vector3(0, 5.0, -3),
      new THREE.Vector3(-1.6, 4.2, -1),
      new THREE.Vector3(2.2, 4.6, -2),
    ];
    centers.forEach((c, i) => {
      const t = setTimeout(() => {
        this.fireworks.burst(c, palette, this.elapsed, 220, 3.8);
      }, i * 380);
      this._fireworkTimers.push(t);
    });
    // 后续每 1.6 秒再补一轮
    this._fireworkInterval = setInterval(() => {
      const c = centers[Math.floor(Math.random() * centers.length)];
      const p = palette[Math.floor(Math.random() * palette.length)];
      this.fireworks.burst(c, [p], this.elapsed, 150, 3.2);
      this.confetti.drop(this.elapsed, 90);
    }, 1600);

    this.confetti.drop(this.elapsed, 280);
    this.field.uniforms.uOrbit.value = 0.16;
  }

  stopCelebrationTimers() {
    (this._fireworkTimers || []).forEach(clearTimeout);
    this._fireworkTimers = [];
    if (this._fireworkInterval) {
      clearInterval(this._fireworkInterval);
      this._fireworkInterval = null;
    }
  }

  /* ------------------------------------------------------------ 更新 */
  update(dt, realDt = dt) {
    // elapsed 用真实时间，动画节奏不随帧率漂移
    this.elapsed = performance.now() / 1000;
    const e = this.elapsed;

    this.bgUniforms.uTime.value = e;
    this.bgUniforms.uCelebrate.value +=
      (this.celebrateAmount - this.bgUniforms.uCelebrate.value) * Math.min(1, dt * 1.2);

    this.field.update(dt, e);
    this.dust.update(e);
    this.fireworks.update(e);
    this.confetti.update(e);
    this.trail.update(dt);

    // 蜡烛
    this.candles.forEach((c) => {
      c.flame.material.uniforms.uTime.value = e;
      c.body.material.uniforms.uTime.value = e;
      if (c.out > 0 && c.out < 1) {
        c.out = Math.min(1, c.out + realDt * 2.6);
        c.flame.material.uniforms.uOut.value = c.out;
        if (c.out >= 1) c.flame.visible = false;
      }
      // 蓄力：吹气进度条由外部驱动，未被吹气的蜡烛自然回落
      const charge = c.charge > 0 ? c.charge : 0;
      c.flame.material.uniforms.uCharge.value +=
        (charge - c.flame.material.uniforms.uCharge.value) * Math.min(1, realDt * 9);
      // 烛焰始终面向相机
      c.flame.quaternion.copy(this.camera.quaternion);
    });

    // 相机：章节目标 + 指针视差 + 呼吸
    this.parallax.lerp(this.parallaxTarget, Math.min(1, dt * 2.4));
    const breathe = this.reducedMotion ? 0 : Math.sin(e * 0.32) * 0.16;
    this.camera.position.x += (this.camTarget.x + this.parallax.x * 0.55 - this.camera.position.x) * Math.min(1, dt * 1.6);
    this.camera.position.y += (this.camTarget.y + this.parallax.y * 0.35 + breathe - this.camera.position.y) * Math.min(1, dt * 1.6);
    this.camera.position.z += (this.camTarget.z - this.camera.position.z) * Math.min(1, dt * 1.1);
    this.lookTarget.lerp(this.lookGoal, Math.min(1, dt * 1.2));
    this.camera.lookAt(this.lookTarget);

    // 主光随蜡烛数量变暗：蜡烛全灭 → 靠烟花与星尘照明
    const lit = this.litCount;
    const targetKey = this.chapter && this.chapter.id === 'second'
      ? 0.6 + lit * 0.55
      : 2.0;
    this.keyLight.intensity += (targetKey - this.keyLight.intensity) * Math.min(1, dt * 1.5);
  }

  render() {
    this.composer.render();
  }

  /** 导出成品图 */
  capture() {
    this.render();
    return this.renderer.domElement.toDataURL('image/png');
  }

  dispose() {
    window.removeEventListener('resize', this.onResize);
    this.field.dispose();
    this.renderer.dispose();
  }
}
