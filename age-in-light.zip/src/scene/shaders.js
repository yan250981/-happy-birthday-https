/**
 * 全部 GLSL 着色器源码。
 * 输出线性色，由 EffectComposer + OutputPass 统一做色调映射与 sRGB 转换。
 *
 * 核心技术：粒子形态变换（Morph Targets）
 * 每个粒子持有 aTargetA / aTargetB 两组目标坐标与 aMorph（该粒子在动画中的相位），
 * 顶点着色器按 uMorphProgress 在两者间插值，并叠加：
 *   - 轨道运动（围绕中心的旋转）
 *   - 手部斥力场（uHandPos + uHandRadius，把粒子推开）
 *   - 呼吸与闪烁
 * 这样一次 draw call 就能完成「文字 → 圆环 → 蛋糕 → 心形」的连续形变。
 */

const NOISE = /* glsl */ `
  float hash21(vec2 p) {
    p = fract(p * vec2(123.34, 456.21));
    p += dot(p, p + 45.32);
    return fract(p.x * p.y);
  }
  float noise2(vec2 p) {
    vec2 i = floor(p), f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    float a = hash21(i);
    float b = hash21(i + vec2(1.0, 0.0));
    float c = hash21(i + vec2(0.0, 1.0));
    float d = hash21(i + vec2(1.0, 1.0));
    return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
  }
  float fbm(vec2 p) {
    float v = 0.0, a = 0.5;
    for (int i = 0; i < 4; i++) { v += a * noise2(p); p *= 2.03; a *= 0.5; }
    return v;
  }
`;

/* ------------------------------------------------------------------ 背景 */
export const BG_VERT = /* glsl */ `
  varying vec2 vUv;
  void main() {
    vUv = uv;
    gl_Position = vec4(position.xy, 1.0, 1.0);
  }
`;

export const BG_FRAG = /* glsl */ `
  precision highp float;
  varying vec2 vUv;
  uniform float uTime;
  uniform float uCelebrate;
  uniform vec2 uResolution;
  ${NOISE}

  void main() {
    vec2 uv = vUv;
    float aspect = uResolution.x / max(uResolution.y, 1.0);
    vec2 p = (uv - 0.5) * vec2(aspect, 1.0);

    vec3 bottom = vec3(0.008, 0.007, 0.020);
    vec3 top    = vec3(0.026, 0.016, 0.052);
    vec3 col = mix(bottom, top, smoothstep(-0.2, 0.95, uv.y));

    // 紫金星云：核心暖金 + 外围紫罗兰（保持克制，让粒子成为主角）
    float neb = fbm(p * 1.15 + vec2(uTime * 0.018, -uTime * 0.012));
    float core = exp(-length(p * vec2(0.78, 1.0)) * 2.4);
    col += vec3(0.052, 0.026, 0.072) * neb * 0.85;
    col += vec3(0.070, 0.032, 0.018) * core * (0.75 + 0.25 * sin(uTime * 0.42));

    // 冷色极光带
    float band = (1.0 - smoothstep(0.46, 0.9, 1.0 - neb)) *
                 (1.0 - smoothstep(0.06, 0.72, abs(p.y - 0.3)));
    col += vec3(0.020, 0.024, 0.052) * band * 0.7;

    // 密星场：两层不同密度
    vec2 sp1 = uv * vec2(aspect, 1.0) * 120.0;
    vec2 si1 = floor(sp1), sf1 = fract(sp1) - 0.5;
    float h1 = hash21(si1);
    float st1 = step(0.975, h1) * (1.0 - smoothstep(0.0, 0.16, length(sf1)));
    col += vec3(0.95, 0.90, 1.0) * st1 * (0.45 + 0.55 * sin(uTime * (1.0 + h1 * 3.0) + h1 * 51.0)) * 0.95;

    vec2 sp2 = uv * vec2(aspect, 1.0) * 52.0;
    vec2 si2 = floor(sp2), sf2 = fract(sp2) - 0.5;
    float h2 = hash21(si2 + 17.3);
    float st2 = step(0.982, h2) * (1.0 - smoothstep(0.0, 0.2, length(sf2)));
    col += vec3(1.0, 0.86, 0.68) * st2 * (0.4 + 0.6 * sin(uTime * 0.8 + h2 * 31.0)) * 0.6;

    // 庆祝时暖意上涌
    col += vec3(0.10, 0.045, 0.020) * uCelebrate * core * 2.0;

    // 暗角（加强，压出舞台感）
    col *= 1.0 - 0.72 * smoothstep(0.18, 0.98, length(p));
    gl_FragColor = vec4(col, 1.0);
  }
`;

/* ------------------------------------------- 主体粒子（形态变换 + 斥力场） */
export const PARTICLE_VERT = /* glsl */ `
  attribute vec3 aTargetA;
  attribute vec3 aTargetB;
  attribute float aMorph;
  attribute float aSeed;
  attribute float aSize;
  attribute vec3 aColor;

  uniform float uTime;
  uniform float uMorphProgress;
  uniform vec3 uHandPos;
  uniform float uHandRadius;
  uniform float uHandForce;
  uniform float uOrbit;
  uniform float uPixelRatio;
  uniform float uBreath;

  varying vec3 vColor;
  varying float vTwinkle;
  varying float vMorph;

  void main() {
    // 形态插值：每个粒子有自己的相位，形成「从内到外逐层重组」的层次感。
    // 延迟幅度压到 0.18 以内，否则末尾会有粒子滞留在旧形态。
    float local = clamp((uMorphProgress - aMorph * 0.18) / 0.82, 0.0, 1.0);
    local = local * local * (3.0 - 2.0 * local);
    vec3 pos = mix(aTargetA, aTargetB, local);

    // 整体自转：所有粒子共用同一个角度，保证字形 / 蛋糕结构不被撕裂
    float ang = uTime * uOrbit;
    float c = cos(ang), s = sin(ang);
    pos.xz = mat2(c, -s, s, c) * pos.xz;

    // 每粒子在形态周围小幅游动，像悬停的尘埃，形状依然清晰
    float w = aSeed * 6.2831;
    float drift = 0.055 * uBreath;
    pos += vec3(
      sin(uTime * 0.72 + w) * drift,
      cos(uTime * 0.57 + w * 1.7) * drift * 0.85,
      sin(uTime * 0.44 + w * 2.3) * drift
    );

    // 手部斥力场：把粒子推开（吹气 / 挥手）
    vec3 toHand = pos - uHandPos;
    float d = length(toHand);
    float infl = 1.0 - smoothstep(0.0, uHandRadius, d);
    pos += normalize(toHand + 0.0001) * infl * infl * uHandForce;

    vec4 mv = modelViewMatrix * vec4(pos, 1.0);
    gl_Position = projectionMatrix * mv;

    float tw = 0.55 + 0.45 * sin(uTime * (1.1 + aSeed * 2.6) + aSeed * 41.0);
    vTwinkle = tw;
    vColor = aColor;
    vMorph = local;

    float base = aSize * (1.0 + 0.28 * sin(uTime * 1.6 + aSeed * 19.0));
    gl_PointSize = base * uPixelRatio * (17.0 / max(-mv.z, 0.1)) * mix(0.35, 1.0, local);
  }
`;

export const PARTICLE_FRAG = /* glsl */ `
  precision highp float;
  varying vec3 vColor;
  varying float vTwinkle;
  varying float vMorph;

  void main() {
    float d = length(gl_PointCoord - 0.5);
    // 硬边小圆点 + 微弱外晕，接近参考站的锐利星点质感
    float core = 1.0 - smoothstep(0.14, 0.30, d);
    float glow = (1.0 - smoothstep(0.05, 0.5, d)) * 0.22;
    float a = clamp(core + glow, 0.0, 1.0);
    vec3 col = vColor * (0.68 + 0.85 * vTwinkle);
    gl_FragColor = vec4(col, a * vTwinkle * mix(0.35, 1.0, vMorph));
  }
`;

/* ------------------------------------------------------------------ 星尘 */
export const DUST_VERT = /* glsl */ `
  attribute float aSeed;
  attribute float aSize;
  attribute vec3 aColor;
  varying vec3 vColor;
  varying float vTw;
  uniform float uTime;
  void main() {
    vec3 p = position;
    p.y += sin(uTime * 0.3 + aSeed * 29.0) * 0.3;
    p.x += cos(uTime * 0.22 + aSeed * 15.0) * 0.24;
    p.z += sin(uTime * 0.18 + aSeed * 8.0) * 0.18;
    vec4 mv = modelViewMatrix * vec4(p, 1.0);
    vTw = 0.35 + 0.65 * sin(uTime * 1.4 + aSeed * 33.0);
    vColor = aColor;
    gl_PointSize = aSize * (22.0 / max(-mv.z, 0.1));
    gl_Position = projectionMatrix * mv;
  }
`;

export const DUST_FRAG = /* glsl */ `
  precision highp float;
  varying vec3 vColor;
  varying float vTw;
  void main() {
    float d = length(gl_PointCoord - 0.5);
    float a = 1.0 - smoothstep(0.0, 0.5, d);
    gl_FragColor = vec4(vColor * (0.7 + 0.6 * a), a * vTw * 0.6);
  }
`;

/* ------------------------------------------------------------------ 烟花 */
export const FIREWORK_VERT = /* glsl */ `
  attribute vec3 aVel;
  attribute vec3 aColor;
  attribute float aStart;
  attribute float aLife;
  attribute float aSize;
  attribute float aSeed;
  varying vec3 vColor;
  varying float vAlpha;
  uniform float uTime;
  uniform float uPixelRatio;
  void main() {
    float age = uTime - aStart;
    float alive = step(0.0, age) * step(age, aLife);
    if (alive < 0.5) {
      gl_Position = vec4(2.0, 2.0, 2.0, 1.0);
      gl_PointSize = 0.0; vAlpha = 0.0; vColor = aColor;
      return;
    }
    float t = max(age, 0.0);
    vec3 p = position + aVel * t;
    p.y -= 1.5 * t * t * 0.5;
    p.x += sin(t * 3.2 + aSeed * 14.0) * 0.05;
    p.z += cos(t * 2.7 + aSeed * 11.0) * 0.05;
    float fade = 1.0 - clamp(t / aLife, 0.0, 1.0);
    vAlpha = pow(fade, 1.5);
    vColor = aColor;
    vec4 mv = modelViewMatrix * vec4(p, 1.0);
    gl_PointSize = aSize * uPixelRatio * (32.0 / max(-mv.z, 0.1)) * (0.35 + 0.65 * fade);
    gl_Position = projectionMatrix * mv;
  }
`;

export const FIREWORK_FRAG = /* glsl */ `
  precision highp float;
  varying vec3 vColor;
  varying float vAlpha;
  void main() {
    float d = length(gl_PointCoord - 0.5);
    float halo = 1.0 - smoothstep(0.0, 0.5, d);
    float core = 1.0 - smoothstep(0.0, 0.15, d);
    vec3 col = vColor * halo * 2.2 + vec3(1.0, 0.95, 0.86) * core * 1.4;
    gl_FragColor = vec4(col, (halo + core) * vAlpha);
  }
`;

/* ------------------------------------------------------------------ 彩带 */
export const CONFETTI_VERT = /* glsl */ `
  attribute vec3 aVel;
  attribute vec3 aColor;
  attribute float aStart;
  attribute float aSeed;
  attribute float aSize;
  varying vec3 vColor;
  varying float vAlpha;
  varying float vAngle;
  uniform float uTime;
  uniform float uPixelRatio;
  void main() {
    float age = uTime - aStart;
    float alive = step(0.0, age) * step(age, 9.0);
    if (alive < 0.5) {
      gl_Position = vec4(2.0, 2.0, 2.0, 1.0);
      gl_PointSize = 0.0; vAlpha = 0.0; vColor = aColor; vAngle = 0.0;
      return;
    }
    float t = max(age, 0.0);
    vec3 p = position;
    p.y -= t * (0.9 + aSeed * 0.8);
    p.x += aVel.x * t + sin(t * 2.1 + aSeed * 21.0) * 0.44;
    p.z += aVel.z * t + cos(t * 1.7 + aSeed * 13.0) * 0.3;
    vAngle = t * (2.3 + aSeed * 5.0) + aSeed * 12.0;
    vAlpha = (1.0 - smoothstep(6.8, 9.0, t)) * smoothstep(0.0, 0.3, t);
    vColor = aColor;
    vec4 mv = modelViewMatrix * vec4(p, 1.0);
    gl_PointSize = aSize * uPixelRatio * (28.0 / max(-mv.z, 0.1));
    gl_Position = projectionMatrix * mv;
  }
`;

export const CONFETTI_FRAG = /* glsl */ `
  precision highp float;
  varying vec3 vColor;
  varying float vAlpha;
  varying float vAngle;
  void main() {
    vec2 uv = gl_PointCoord - 0.5;
    float c = cos(vAngle), s = sin(vAngle);
    vec2 r = vec2(uv.x * c - uv.y * s, uv.x * s + uv.y * c);
    float rect = step(abs(r.x), 0.16) * step(abs(r.y), 0.46);
    float edge = 1.0 - smoothstep(0.09, 0.17, abs(r.x));
    gl_FragColor = vec4(vColor * (0.85 + edge * 0.65), rect * vAlpha * 0.95);
  }
`;

/* -------------------------------------------------------------- 手部轨迹 */
export const TRAIL_VERT = /* glsl */ `
  attribute float aLife;
  attribute vec3 aColor;
  attribute float aSize;
  varying vec3 vColor;
  varying float vAlpha;
  uniform float uPixelRatio;
  void main() {
    vec4 mv = modelViewMatrix * vec4(position, 1.0);
    vColor = aColor;
    vAlpha = aLife;
    gl_PointSize = aSize * uPixelRatio * (26.0 / max(-mv.z, 0.1)) * aLife;
    gl_Position = projectionMatrix * mv;
  }
`;

export const TRAIL_FRAG = /* glsl */ `
  precision highp float;
  varying vec3 vColor;
  varying float vAlpha;
  void main() {
    float d = length(gl_PointCoord - 0.5);
    float a = 1.0 - smoothstep(0.0, 0.5, d);
    gl_FragColor = vec4(vColor * 1.3, a * a * vAlpha);
  }
`;

/* ------------------------------------------------------------------ 烛火 */
export const FLAME_VERT = /* glsl */ `
  varying vec2 vUv;
  uniform float uTime;
  uniform float uSeed;
  uniform float uOut;
  uniform float uCharge;
  void main() {
    vUv = uv;
    vec3 pos = position;
    pos.x += sin(uTime * 7.0 + uSeed * 11.0 + uv.y * 5.0) * 0.04 * uv.y;
    // 蓄力吹气：火焰被"吹"得膨胀、变高
    pos.x *= 1.0 - uCharge * 0.18;
    pos.y *= 1.0 + uCharge * 0.55;
    pos *= mix(1.0, 0.28, uOut);
    pos.y += uOut * 0.22;
    gl_Position = projectionMatrix * modelViewMatrix * vec4(pos, 1.0);
  }
`;

export const FLAME_FRAG = /* glsl */ `
  precision highp float;
  varying vec2 vUv;
  uniform float uTime;
  uniform float uSeed;
  uniform float uOut;
  uniform float uCharge;
  ${NOISE}
  void main() {
    vec2 uv = vUv;
    float t = uTime * 2.6 + uSeed * 23.0;
    float wobble = (sin(t * 2.1 + uv.y * 6.5) * 0.55 + noise2(vec2(uv.y * 3.5, t * 0.7)) - 0.5) * 0.12;
    float cx = 0.5 + wobble * smoothstep(0.0, 1.0, uv.y);
    float halfW = 0.215 * pow(max(0.0, 1.0 - uv.y), 0.6) * (1.0 + 0.1 * sin(t * 3.2));
    float d = abs(uv.x - cx) / max(halfW, 0.001);
    float shape = 1.0 - smoothstep(0.16, 1.0, d);
    shape *= smoothstep(0.0, 0.1, uv.y) * (1.0 - smoothstep(0.78, 1.0, uv.y));

    vec3 outer = vec3(1.0, 0.22, 0.04);
    vec3 mid   = vec3(1.0, 0.68, 0.14);
    vec3 core  = vec3(1.0, 0.96, 0.78);
    vec3 col = mix(outer, mid, 1.0 - smoothstep(0.28, 1.0, d));
    col = mix(col, core, (1.0 - smoothstep(0.0, 0.46, d)) * smoothstep(0.02, 0.36, uv.y));

    float flick = 0.82 + 0.18 * sin(t * 5.4 + uSeed * 9.0);
    float halo = exp(-length(vec2((uv.x - cx) * 3.2, (uv.y - 0.36) * 2.0)) * 2.5) * 0.26;
    float alpha = clamp(shape * flick + halo * flick, 0.0, 1.0) * (1.0 - uOut);
    // 蓄力时焰色偏向白亮，边缘泛起热浪般的暖光
    col = mix(col, vec3(1.0, 0.93, 0.72), uCharge * 0.55);
    float glow = 1.0 + uCharge * 1.35;
    gl_FragColor = vec4(col * ((1.3 + 0.6 * (1.0 - smoothstep(0.0, 0.6, d))) * glow), alpha);
  }
`;

/* -------------------------------------------------------------- 烛身/蛋糕 */
export const CAKE_VERT = /* glsl */ `
  varying vec3 vNormal;
  varying vec2 vUv;
  varying float vY;
  void main() {
    vUv = uv;
    vNormal = normalize(normalMatrix * normal);
    vec4 wp = modelMatrix * vec4(position, 1.0);
    vY = position.y;
    gl_Position = projectionMatrix * viewMatrix * wp;
  }
`;

export const CAKE_FRAG = /* glsl */ `
  precision highp float;
  varying vec3 vNormal;
  varying vec2 vUv;
  varying float vY;
  uniform vec3 uColorA;
  uniform vec3 uColorB;
  uniform float uTime;
  uniform float uOpacity;
  ${NOISE}
  void main() {
    vec3 n = normalize(vNormal);
    float rim = pow(1.0 - max(dot(n, vec3(0.0, 0.0, 1.0)), 0.0), 2.2);
    float grad = smoothstep(-1.1, 1.1, vY);
    vec3 col = mix(uColorA, uColorB, grad);
    // 釉面高光带
    float glaze = smoothstep(0.02, 0.16, abs(fract(vY * 1.6) - 0.5)) * 0.25;
    col += vec3(1.0, 0.86, 0.72) * glaze * (0.4 + rim);
    col += vec3(1.0, 0.72, 0.45) * rim * 0.85;
    float speck = noise2(vUv * 120.0) * 0.08;
    col += speck;
    gl_FragColor = vec4(col, uOpacity);
  }
`;
