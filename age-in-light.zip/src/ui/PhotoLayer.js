import { PHOTOS, VIDEO_ITEM, makeAvatar, probeAssetsQuietly } from '../assets/media.js';

/**
 * 漂浮照片卡片层。
 * 参考站的做法：照片不放在页面里，而是作为 3D 空间的悬浮物，
 * 跟随粒子轨道缓慢公转。这里用 DOM + transform 实现，
 * 保证缩略图清晰、标签可读，同时不增加 WebGL 负担。
 */
export class PhotoLayer {
  constructor(container) {
    this.container = container;
    this.cards = [];
    this.items = [];
  }

  /** 延迟加载：进入章节时才探测素材是否存在 */
  async load() {
    const items = [];

    // 一次性静默探测所有候选资源
    const candidates = [...PHOTOS.map((p) => p.src), VIDEO_ITEM.src];
    const found = await probeAssetsQuietly(candidates);
    const photoUrls = found.slice(0, PHOTOS.length);
    const videoUrl = found[found.length - 1];

    // 照片：占位符兜底
    const probes = PHOTOS.map((p, i) => ({
      ...p,
      glyph: p.fallback,
      image: photoUrls[i] ? p.src : makeAvatar(p.fallback, i),
      isReal: !!photoUrls[i],
    }));
    items.push(...probes);

    // 视频位
    items.push({
      ...VIDEO_ITEM,
      glyph: '▶',
      image: makeAvatar('▶', 21),
      isVideo: true,
      isReal: !!videoUrl,
      videoSrc: videoUrl,
    });

    this.items = items;
    this._build();
    return items;
  }

  _build() {
    this.container.innerHTML = '';
    this.cards = this.items.map((item, i) => {
      const fig = document.createElement('figure');
      fig.className = 'photo-card' + (item.isVideo ? ' is-video' : '');
      const img = document.createElement('img');
      img.src = item.image;
      img.alt = item.name;
      img.loading = 'lazy';
      const cap = document.createElement('figcaption');
      cap.textContent = item.name;
      fig.appendChild(img);
      fig.appendChild(cap);
      this.container.appendChild(fig);
      return { el: fig, item, phase: (i / this.items.length) * Math.PI * 2 };
    });
  }

  /**
   * 每帧更新位置：卡片沿轨道公转 + 轻微上下浮动 + 深度缩放。
   * 位置用 CSS transform，避免布局重排。
   */
  update(elapsed, w, h) {
    if (!this.cards.length) return;
    const cx = w * 0.5;
    const cy = h * 0.44;
    // 椭圆轨道：横向铺开、纵向收窄，贴近参考站里卫星环绕粒子场的感觉
    const rx = w * 0.36;
    const ry = h * 0.34;
    // 主体（蛋糕/文字）在画面正中约 ±26% 宽度，占位区不排卡片
    const keepOutX = w * 0.235;

    this.cards.forEach((c, i) => {
      const t = elapsed * 0.07 + c.phase;
      // 每个卡片有各自的轨道半径与倾角，避免排成一条线
      const kr = 0.78 + ((i * 37) % 11) / 11 * 0.46;
      const tilt = ((i * 53) % 7) / 7 * 0.42 - 0.21;
      const x = cx + Math.cos(t) * rx * kr;
      const y = cy + Math.sin(t + tilt) * ry * kr + Math.sin(elapsed * 0.9 + i * 1.7) * 8;
      // 横向挤进主体时推到主体外缘，纵向放行（上下方本来就是空场）
      const dx = x - cx;
      const pushed = Math.abs(dx) < keepOutX
        ? cx + Math.sign(dx || 1) * keepOutX
        : x;
      const depth = (Math.sin(t) + 1) / 2;
      const scale = 0.52 + depth * 0.55;
      const op = 0.26 + depth * 0.64;
      c.el.style.transform = `translate3d(${pushed.toFixed(1)}px, ${y.toFixed(1)}px, 0) scale(${scale.toFixed(3)})`;
      c.el.style.opacity = op.toFixed(3);
      c.el.style.zIndex = String(100 + Math.round(depth * 100));
    });
  }

  setVisible(v) {
    this.container.style.display = v ? '' : 'none';
  }
}
