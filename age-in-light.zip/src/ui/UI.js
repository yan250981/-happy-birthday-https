import { CHAPTERS } from '../scene/World.js';

/**
 * DOM 界面管理：章节导视、解说条、提示气泡、Toast、封面、结尾、设置。
 */
export class UI {
  constructor() {
    this.$ = (id) => document.getElementById(id);
    this.rail = this.$('rail');
    this.dots = this.$('dots');
    this.caption = this.$('caption');
    this.tip = this.$('tip');
    this.toastEl = this.$('toast');
    this.cover = this.$('cover');
    this.finale = this.$('finale');
    this.loader = this.$('loader');
    this.settings = this.$('settings');
    this.app = this.$('app');
    this._tipTimer = null;
    this._toastTimer = null;
    this._buildDots();
    this._bindSettingsDismiss();
  }

  _buildDots() {
    this.dots.innerHTML = '';
    CHAPTERS.forEach((ch, i) => {
      const b = document.createElement('button');
      b.className = 'dot';
      b.type = 'button';
      b.title = `${ch.index} ${ch.cn}`;
      b.setAttribute('aria-label', ch.title);
      b.addEventListener('click', () => {
        if (this.onDot) this.onDot(i);
      });
      this.dots.appendChild(b);
    });
    const label = document.createElement('span');
    label.className = 'dot-label';
    label.id = 'dot-label';
    label.textContent = '1 / 4';
    this.dots.appendChild(label);
  }

  /* ---------------------------------------------------------- 章节 */
  setChapter(index) {
    const ch = CHAPTERS[index];
    if (!ch) return;
    this.$('chapter-index').textContent = ch.index;
    this.$('chapter-cn').textContent = ch.cn;
    this.$('chapter-title').textContent = ch.title;
    this.$('chapter-sub').textContent = ch.sub;
    this.$('cap-eyebrow').textContent = `${ch.index} · ${ch.cn}`;
    this.$('cap-text').textContent = ch.caption;
    const label = this.$('dot-label');
    if (label) label.textContent = `${index + 1} / ${CHAPTERS.length}`;
    Array.from(this.dots.children).forEach((el, i) => {
      if (!el.classList.contains('dot')) return;
      el.classList.toggle('is-on', i === index);
      el.classList.toggle('is-done', i < index);
    });
    this.rail.classList.remove('hidden');
    this.caption.classList.remove('hidden');
  }

  showRail(v) {
    this.rail.classList.toggle('hidden', !v);
    this.caption.classList.toggle('hidden', !v);
  }

  /* ---------------------------------------------------------- 提示 */
  showTip(text, ms = 4200) {
    this.tip.textContent = text;
    this.tip.classList.remove('hidden');
    this.tip.style.animation = 'none';
    void this.tip.offsetWidth;
    this.tip.style.animation = '';
    clearTimeout(this._tipTimer);
    if (ms > 0) {
      this._tipTimer = setTimeout(() => this.tip.classList.add('hidden'), ms);
    }
  }

  hideTip() {
    clearTimeout(this._tipTimer);
    this.tip.classList.add('hidden');
  }

  toast(text, ms = 2600) {
    this.toastEl.textContent = text;
    this.toastEl.classList.add('is-on');
    clearTimeout(this._toastTimer);
    this._toastTimer = setTimeout(() => this.toastEl.classList.remove('is-on'), ms);
  }

  /* ---------------------------------------------------------- 封面 */
  hideCover() {
    this.cover.classList.add('is-out');
    setTimeout(() => this.cover.classList.add('hidden'), 850);
  }

  showCover() {
    this.cover.classList.remove('hidden');
    requestAnimationFrame(() => this.cover.classList.remove('is-out'));
  }

  setCoverData({ to, from, msg }) {
    if (to) this.$('cover-to').textContent = `${to}，生日快乐`;
    if (msg) this.$('cover-sub').textContent = msg;
    if (from) {
      const sign = this.$('finale-sign');
      sign.textContent = `—— 来自 ${from}`;
    }
    if (to) {
      const f = this.$('finale-title');
      f.textContent = `${to}，生日快乐`;
    }
  }

  setCopyState(text) {
    this.$('copy-state').textContent = text || '';
  }

  /* ---------------------------------------------------------- 结尾 */
  showFinale() {
    this.finale.classList.remove('hidden');
    this.showRail(false);
  }

  hideFinale() {
    this.finale.classList.add('hidden');
  }

  /* ---------------------------------------------------------- 设置 */
  toggleSettings(v) {
    const show = v === undefined ? this.settings.classList.contains('hidden') : v;
    this.settings.classList.toggle('hidden', !show);
    return show;
  }

  /**
   * 设置面板的关闭方式：再次点击齿轮、点面板外的遮罩、或按 Escape。
   * 只支持「再点一次齿轮」会让人以为面板卡住。
   */
  _bindSettingsDismiss() {
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && !this.settings.classList.contains('hidden')) {
        this.toggleSettings(false);
      }
    });
    // 点击面板外的遮罩区域关闭
    this.settings.addEventListener('click', (e) => {
      if (e.target === this.settings) this.toggleSettings(false);
    });
  }

  setSoundState(on) {
    this.$('btn-sound').classList.toggle('is-on', on);
  }

  setHandsState(on) {
    this.$('btn-toggle-hands').classList.toggle('is-on', on);
  }

  setQuality(q) {
    Array.from(this.$('seg-quality').children).forEach((b) => {
      b.classList.toggle('is-on', b.dataset.q === q);
    });
  }

  /* ---------------------------------------------------------- 加载 */
  setLoader(text) {
    const t = this.$('loader-text');
    if (t) t.textContent = text;
  }

  hideLoader() {
    this.loader.classList.add('is-out');
  }

  setSpectator(v) {
    this.app.classList.toggle('is-spectator', v);
  }

  setCamVisible(v) {
    this.$('cam-wrap').classList.toggle('hidden', !v);
  }

  setCamHint(text) {
    this.$('cam-hint').textContent = text;
  }

  setCamLive(on) {
    this.$('cam-dot').classList.toggle('is-live', on);
  }

  setBrand(to) {
    if (to) this.$('brand-name').textContent = to;
  }
}
