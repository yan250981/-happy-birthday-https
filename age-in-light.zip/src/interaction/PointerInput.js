/**
 * 鼠标 / 触摸输入，与手势共用同一套「世界坐标 + 力度」输出协议。
 * 授权被拒或用户选择鼠标模式时接管，保证流程不中断。
 */
export class PointerInput {
  constructor(canvas, opts = {}) {
    this.canvas = canvas;
    this.onBlow = opts.onBlow || (() => {});
    this.onShape = opts.onShape || (() => {});
    this.onMove = opts.onMove || (() => {});
    this.onDown = opts.onDown || (() => {});

    this.ndc = { x: 0, y: 0 };
    this.down = false;
    this.active = false;
    this.speed = 0;
    this._last = { x: 0, y: 0, t: 0 };
    this._blowCool = 0;
    this._pinchCool = 0;

    this._bind();
  }

  _bind() {
    const el = this.canvas;

    const move = (e) => {
      const rect = el.getBoundingClientRect();
      const x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      const y = -(((e.clientY - rect.top) / rect.height) * 2 - 1);
      const now = performance.now();
      // 首次移动没有参照，用 16ms 兜底；之后用真实时间差
      const dt = this._last.t ? Math.max(8, now - this._last.t) : 16;
      const dist = Math.hypot(x - this._last.x, y - this._last.y);
      // 速度：NDC 单位 / 秒
      const instant = (dist / dt) * 1000;
      // 事件里测得的速度直接生效；只做一次轻度回退，
      // 让连续的多个 move 事件能累积成「快速划过」的判定
      this.speed = Math.max(this.speed * 0.5, instant);
      this._last = { x, y, t: now };
      this.ndc.x = x;
      this.ndc.y = y;
      this.active = true;
      this.onMove(this.ndc, this.speed);
    };

    el.addEventListener('pointermove', move, { passive: true });
    el.addEventListener('pointerdown', (e) => {
      this.down = true;
      this._last.t = performance.now();
      // 按下即捏合 → 触发塑形彩蛋（手势模式的等价操作）
      this.onShape(this.ndc);
      this.onDown(this.ndc);
      el.setPointerCapture?.(e.pointerId);
    });
    el.addEventListener('pointerup', () => { this.down = false; });
    el.addEventListener('pointerleave', () => { this.active = false; });
    el.addEventListener('pointercancel', () => { this.down = false; });
  }

  /**
   * 每帧调用。
   * @param {number} dt
   * @param {(ndc, speed)=>any} hitTest 返回非空值表示命中可吹灭目标，
   *        返回值会透传给 onBlow（用于锁定具体目标）
   */
  update(dt, hitTest) {
    this._blowCool = Math.max(0, this._blowCool - dt);

    if (!this.active) {
      this.speed *= Math.pow(0.02, dt);
      return;
    }

    // 快速划过目标 → 吹气；或按住点击目标 → 直接吹灭
    // 阈值：正常移动约 1-3 NDC/s，快速划过 5+，
    // 因此 2.2 既不会误触发普通移动，又能捕捉到「扇过去」的动作
    const fast = this.speed > 2.2;
    const hit = hitTest ? hitTest(this.ndc, this.speed) : null;
    if (this._blowCool === 0 && hit) {
      if (fast || this.down) {
        this.onBlow(hit);
        this._blowCool = 0.5;
      }
    }
    // 速度按时间常数回落（约 0.3 秒半衰），与帧率无关
    this.speed *= Math.pow(0.06, dt);
  }

  getState() {
    return {
      active: this.active,
      x: this.ndc.x,
      y: this.ndc.y,
      z: 0,
      pinch: this.down,
      open: !this.down,
    };
  }

  dispose() {}
}
