import { HandLandmarker, FilesetResolver } from '@mediapipe/tasks-vision';

/**
 * 手势输入封装。
 * - 本地 wasm + 本地模型，不依赖 CDN
 * - 关键点做指数平滑，避免抖动
 * - 捏合判定用「拇指尖-食指尖距离 / 手掌尺度」的比值，带迟滞
 * - 张开判定用「指尖到手腕距离 / 手掌尺度」
 */

const BASE = import.meta.env.BASE_URL || '/';

/** MediaPipe 手部关键点连线（用于小窗骨架绘制） */
export const HAND_CONNECTIONS = [
  [0, 1], [1, 2], [2, 3], [3, 4],
  [0, 5], [5, 6], [6, 7], [7, 8],
  [5, 9], [9, 10], [10, 11], [11, 12],
  [9, 13], [13, 14], [14, 15], [15, 16],
  [13, 17], [17, 18], [18, 19], [19, 20],
  [0, 17],
];

export class HandInput {
  constructor(opts = {}) {
    this.video = opts.video;
    this.overlay = opts.overlay;
    this.onStatus = opts.onStatus || (() => {});

    this.active = false;
    this.landmarker = null;
    this.stream = null;
    this.lastVideoTime = -1;
    this.rafId = null;

    // 平滑后的状态
    this.smooth = { x: 0, y: 0, z: 0 };
    this.pinchRatio = 1;
    this.isPinching = false;
    this.isOpen = false;
    this.landmarks = null;

    this._pinchOn = false;
    this._pinchOff = 0;
  }

  /** 初始化模型（本地资源） */
  async init() {
    this.onStatus('正在加载手势模型…');
    const fileset = await FilesetResolver.forVisionTasks(`${BASE}mediapipe/wasm`);
    this.landmarker = await HandLandmarker.createFromOptions(fileset, {
      baseOptions: {
        modelAssetPath: `${BASE}mediapipe/hand_landmarker.task`,
        delegate: 'GPU',
      },
      runningMode: 'VIDEO',
      numHands: 1,
      minHandDetectionConfidence: 0.55,
      minHandPresenceConfidence: 0.55,
      minTrackingConfidence: 0.55,
    });
    this.onStatus('模型就绪');
  }

  /** 请求摄像头并启动推理循环 */
  async start() {
    if (!this.landmarker) await this.init();
    this.onStatus('正在唤醒摄像头…');
    this.stream = await navigator.mediaDevices.getUserMedia({
      video: { width: { ideal: 640 }, height: { ideal: 480 }, facingMode: 'user' },
      audio: false,
    });
    this.video.srcObject = this.stream;
    await this.video.play();
    this.active = true;
    this.onStatus('追踪中');
    this._loop();
  }

  stop() {
    this.active = false;
    if (this.rafId) cancelAnimationFrame(this.rafId);
    this.rafId = null;
    if (this.stream) {
      this.stream.getTracks().forEach((t) => t.stop());
      this.stream = null;
    }
    if (this.video) this.video.srcObject = null;
    this.landmarks = null;
    this.isPinching = false;
    this.isOpen = false;
    this.onStatus('已关闭');
  }

  _loop() {
    if (!this.active) return;
    this.rafId = requestAnimationFrame(() => this._loop());
    const v = this.video;
    if (!v || v.readyState < 2 || v.videoWidth === 0) return;
    if (v.currentTime === this.lastVideoTime) return;
    this.lastVideoTime = v.currentTime;

    let result;
    try {
      result = this.landmarker.detectForVideo(v, performance.now());
    } catch (err) {
      return;
    }

    const lm = result.landmarks && result.landmarks[0];
    if (!lm) {
      this.landmarks = null;
      this.isPinching = false;
      this.isOpen = false;
      this._drawOverlay(null);
      return;
    }
    this.landmarks = lm;
    this._analyze(lm);
    this._drawOverlay(lm);
  }

  _analyze(lm) {
    const wrist = lm[0];
    const thumb = lm[4];
    const index = lm[8];
    const middle = lm[12];
    const ring = lm[16];
    const pinky = lm[20];
    const indexMcp = lm[5];
    const pinkyMcp = lm[17];

    const d = (a, b) => Math.hypot(a.x - b.x, a.y - b.y, (a.z - b.z) * 0.6);

    // 手掌尺度：腕 → 中指根，作为所有距离的归一化基准
    const palmScale = Math.max(d(wrist, indexMcp), d(wrist, pinkyMcp), 0.02);

    // 捏合比值：拇指尖与食指尖距离 / 手掌尺度
    const rawPinch = d(thumb, index) / palmScale;
    this.pinchRatio = this.pinchRatio * 0.72 + rawPinch * 0.28;

    // 迟滞：低于 0.42 判定捏合，高于 0.58 解除
    if (!this._pinchOn && this.pinchRatio < 0.42) this._pinchOn = true;
    else if (this._pinchOn && this.pinchRatio > 0.58) this._pinchOn = false;
    this.isPinching = this._pinchOn;

    // 张开：四指尖到手腕的距离都明显大于掌宽
    const fingers = [index, middle, ring, pinky];
    const extended = fingers.filter((f) => d(f, wrist) / palmScale > 1.45).length;
    this.isOpen = extended >= 3 && !this.isPinching;

    // 指尖位置（NDC，已镜像以匹配用户直觉）
    const tip = index;
    const rawX = (1 - tip.x) * 2 - 1;
    const rawY = -(tip.y * 2 - 1);
    const k = 0.42;
    this.smooth.x = this.smooth.x * (1 - k) + rawX * k;
    this.smooth.y = this.smooth.y * (1 - k) + rawY * k;
    this.smooth.z = this.smooth.z * (1 - k) + (tip.z || 0) * k;
  }

  /** 返回给上层的手势状态 */
  getState() {
    if (!this.landmarks) return null;
    return {
      active: true,
      x: this.smooth.x,
      y: this.smooth.y,
      z: this.smooth.z,
      pinch: this.isPinching,
      open: this.isOpen,
    };
  }

  _drawOverlay(lm) {
    const c = this.overlay;
    if (!c) return;
    const v = this.video;
    const w = v.videoWidth || 640;
    const h = v.videoHeight || 480;
    if (c.width !== w || c.height !== h) {
      c.width = w;
      c.height = h;
    }
    const ctx = c.getContext('2d');
    ctx.clearRect(0, 0, w, h);
    if (!lm) return;

    // 视频已 CSS scaleX(-1) 镜像，绘制时同样翻转 x
    const px = (p) => (1 - p.x) * w;
    const py = (p) => p.y * h;

    ctx.strokeStyle = this.isPinching ? 'rgba(255,158,196,0.95)' : 'rgba(255,215,160,0.8)';
    ctx.lineWidth = 2.2;
    ctx.lineCap = 'round';
    HAND_CONNECTIONS.forEach(([a, b]) => {
      ctx.beginPath();
      ctx.moveTo(px(lm[a]), py(lm[a]));
      ctx.lineTo(px(lm[b]), py(lm[b]));
      ctx.stroke();
    });

    ctx.fillStyle = 'rgba(255,240,214,0.95)';
    lm.forEach((p, i) => {
      const r = i === 4 || i === 8 ? 5.2 : 3.1;
      ctx.beginPath();
      ctx.arc(px(p), py(p), r, 0, Math.PI * 2);
      ctx.fill();
    });

    // 捏合时画一条连接线，视觉反馈更明确
    if (this.isPinching) {
      ctx.strokeStyle = 'rgba(255,158,196,1)';
      ctx.lineWidth = 2.6;
      ctx.beginPath();
      ctx.moveTo(px(lm[4]), py(lm[4]));
      ctx.lineTo(px(lm[8]), py(lm[8]));
      ctx.stroke();
    }
  }

  dispose() {
    this.stop();
    if (this.landmarker) {
      this.landmarker.close();
      this.landmarker = null;
    }
  }
}
